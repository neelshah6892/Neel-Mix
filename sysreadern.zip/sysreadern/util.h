
#pragma once
#define MAX_MESSAGE_SIZE 512
void converttolittle(char *src, int len);
void byteSwap(void *data, int dataLength) ;
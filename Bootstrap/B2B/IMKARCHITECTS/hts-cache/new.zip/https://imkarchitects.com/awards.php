<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>I M Kadri</title>

<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>
</head>

<body>

<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="active" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main_inner">
   <!--slider
    <div class="inner_banner">
       <img src="images/inner-banner.jpg">
       <div class="banner_text">
          <div class="Title"> Team</div>
      </div>
    </div>
-->
    
    <div class="Inner_Page">
      <div class="breadcrumb mrg_btm top_bdr">
          <div class="container">
            <ul>
                <li><a href="index.php"><i class="fa_bedcrum fa-home" aria-hidden="true"></i></a></li>
                <li><a href="#">media</a></li>
                <li>Awards</li>
            </ul>
          </div>
      </div>
      
      <div class="Awards_Section">
        <div class="container">
          <h1 class="Title">Awards</h1>
          <div class="sub_title"> Mr. I.M. Kadri</div>
          <div class="Awards_Row">
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery" title="I.M. Kadri wins the Sir Mokshagundam Visvesvaraya Trophy Lifetime Achievement Award at CIDC Vishwakarma Awards March 2021" href="images/awards/cidc-vishwakarma.jpg"> 
                      <img class="grayscale" src="images/awards/cidc-vishwakarma.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">CIDC Vishwakarma Lifetime Achievement Award  <span>March 2021</span></div>
              </div>
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery" title="Al-Barkaat Education Society, Aligarh Presented Mr. I.M.Kadri, Renowned Architect on the occasion of Annual Day Function of Al-Barkaat Education Society on 29th November 2008." href="images/awards/al-barkaat-education.jpg"> 
                      <img class="grayscale" src="images/awards/al-barkaat-education.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Al Barkaat education<span>November 2008</span></div>
              </div>
            
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery1" title="Shree Shanmukhananda Sabhagriha, Mumbai
                    Presented Mr. I.M.Kadri, on Golden Jubilee 2002- 2003 by Shree Shanmukhananda Fine Arts and Sangeetha Sabha" href="images/awards/shanmukhanad.jpg"> 
                      <img class="grayscale" src="images/awards/shanmukhanad.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Shanmukhananda Sabhagriha <span>2002- 2003</span></div>
              </div>
            
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery2" title="Indian Institute of Interiors Designers
                      Mr. I.M.Kadri conferred as  Fellow of Indian Institute of interior designers on 29th April 1995
                      " href="images/awards/indian-institute-of-interiors-1995.jpg"> 
                      <img class="grayscale" src="images/awards/indian-institute-of-interiors-1995.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Indian Institute of Interiors <span>April 1995</span></div>
              </div>
            
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery3" title="Mr. I.M. Kadri Awarded a Citation in 1993 as an Outstanding Architectural Engineer by the Institution of Engineers (India), Architectural Engineering Division" href="images/awards/architectural-engineering-division-1993.jpg"> 
                      <img class="grayscale" src="images/awards/architectural-engineering-division-1993.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Architectural Engineering Division <span>1993</span></div>
              </div>
            
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery6" title="Mr. I.M.Kadri appointed as Sheriff of Bombay,<br /> Year 1994" href="images/awards/i.m.kadri-appointed-as-sheriff-of-bombay.jpg"> 
                      <img class="grayscale" src="images/awards/i.m.kadri-appointed-as-sheriff-of-bombay.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Mr. I.M.Kadri appointed as Sheriff of Bombay,<span> Year 1994 </span></div>
              </div>
           
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery7" title="Felicitation of Mr. I.M. Kadri by Pandit Nehru,<br /> New Delhi" href="images/awards/felicitation-i.m.kadri.jpg"> 
                      <img class="grayscale" src="images/awards/felicitation-i.m.kadri.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Felicitation of Mr. I.M. Kadri by Pandit Nehru, New Delhi</div>
              </div>
           
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery8" title="Worlds highest stained glass mural,<br />Ramada Hotel, Dubai" href="images/awards/worlds-highest-stained-glass-mural.jpg"> 
                      <img class="grayscale" src="images/awards/worlds-highest-stained-glass-mural.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Worlds highest stained glass mural, Ramada Hotel, Dubai </div>
              </div>
            
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery4" title="United arab emirates mosque by IMK <br />on postal stamp" href="images/awards/postal-stamp.jpg"> 
                      <img class="grayscale" src="images/awards/postal-stamp.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Mosque by IMK on Postal Stamp, United Arab Emirates </div>
              </div>
           
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery9" title="Indexcellence Award  celebrating the creative Genius of Ar. I.M.Kadri, <br />I.M.Kadri Architects" href="images/awards/indexcellence-award.jpg"> 
                      <img class="grayscale" src="images/awards/indexcellence-award.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">indexcellence award </div>
              </div>
           
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery5" title="Mr. I.M. Kadri was the Winner of the Best Design Award at the International Competition for the “Kowloon Mosque” in Hong Kong.The International Who’s Who of Intellectuals" href="images/awards/international-who-who-of-intellectuals.jpg"> 
                      <img class="grayscale" src="images/awards/international-who-who-of-intellectuals.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">International Who’s Who of Intellectuals <span>July 1979</span></div>
              </div>
           
              <div class="Awards_Box">
                <div class="Awards_Thum">
                    <a class="venobox" data-gall="myGallery21" title="Lifetime Achievement Award" href="images/awards/imk-lifetime-achievement-award.jpg"> 
                      <img class="grayscale" src="images/awards/imk-lifetime-achievement-award.jpg" alt="" />
                    </a>
                </div>
                <div class="Awards_Name">Lifetime Achievement Award  </div>
              </div>
            
          </div>
        </div>

        <div class="awards_top_bdr">
          <div class="container">
            <div class="sub_title"> Mr. Rahul Kadri</div>
            <div class="Awards_Row">
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery22" title="IMK Architects’ Symbiosis University Hospital and Research Centre wins the Public Building Exterior Category  and Supreme Winner Award at  Surface Design Awards 2021" href="images/awards/rk/surface-design-awards-2021.jpg"> 
                        <img class="grayscale" src="images/awards/rk/surface-design-awards-2021.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name">IMK Architects’ Symbiosis University Hospital and Research Centre wins the Public Building Exterior Category  and Supreme Winner Award at  Surface Design Awards 2021  </div>
                </div>

                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery21" title="CWAB Awards 2020 selects IMK Architects as India’s Top Architects 2020" href="images/awards/rk/india-top-architects-2020.jpg"> 
                        <img class="grayscale" src="images/awards/rk/india-top-architects-2020.jpg" alt="" />
                      </a>
                       <a class="venobox" data-gall="myGallery21" title="CWAB Awards 2020 selects IMK Architects as India’s Top Architects 2020" href="images/awards/rk/india-top-architects-2020-2.jpg"> </a>
                  </div>
                  <div class="Awards_Name">CWAB Awards 2020 selects IMK Architects as India’s Top Architects 2020  </div>
                </div>
             
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery10" title="Times Network presents “Architect of the Year “ Awarded to Mr Rahul Kadri, Principal Architect and Partner of I.M.Kadri Architects for AURIC project at Aurangabad on 7th July 2017" href="images/awards/rk/times-network-2017.jpg"> 
                        <img class="grayscale" src="images/awards/rk/times-network-2017.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name">Times Network   <span>July 2017</span></div>
                </div>
             
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery11" title="‘Excellence in Architecture & Design’ awarded to Mr. Rahul Kadri by <br />Festival of Architecture & Interior Designing 2016" href="images/awards/rk/foaid2016.jpg"> 
                        <img class="grayscale" src="images/awards/rk/foaid2016.jpg" alt="" />
                      </a>
                       <a class="venobox" data-gall="myGallery11" title="‘Excellence in Architecture & Design’ awarded to Mr. Rahul Kadri by Festival of Architecture & Interior Designing 2016" href="images/awards/rk/foaid2.jpg"> </a>
                  </div>
                  <div class="Awards_Name">Foaid  <span>2016</span></div>
                </div>
             
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery12" title="CWAB Awards 2016" href="images/awards/rk/cwab-2016.jpg"> 
                        <img class="grayscale" src="images/awards/rk/cwab-2016.jpg" alt="" />
                      </a>
                      <a class="venobox" data-gall="myGallery12" title="CWAB Awards 2016" href="images/awards/rk/cwab-2016-1.jpg"> </a>
                      <a class="venobox" data-gall="myGallery12" title="CWAB Awards 2016" href="images/awards/rk/cwab-2016-2.jpg"> </a>
                  </div>
                  <div class="Awards_Name">CWAB Awards <span>2016</span></div>
                </div>
              
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery13" title="Felicitation of Mr. Rahul Kadri  from Academy of Architecture" href="images/awards/rk/felicitation-academy-of-arch.jpg"> 
                        <img class="grayscale" src="images/awards/rk/felicitation-academy-of-arch.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name"> Felicitation Academy of arch <span>2015</span> </div>
                </div>
              
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery14" title="Mr. Rahul Kadri felicitated as India's Top 10 Inno-visionary Architects at the CWAB Awards 2014 hosted by CW Interiors, August 2014" href="images/awards/rk/cwab-awards2014.jpg"> 
                        <img class="grayscale" src="images/awards/rk/cwab-awards2014.jpg" alt="" />
                      </a>
                      <a class="venobox" data-gall="myGallery14" title="Mr. Rahul Kadri felicitated as India's Top 10 Inno-visionary Architects at the CWAB Awards 2014 hosted by CW Interiors, August 2014" href="images/awards/rk/cwab-awards2014-2.jpg"> </a>
                      <a class="venobox" data-gall="myGallery14" title="Mr. Rahul Kadri felicitated as India's Top 10 Inno-visionary Architects at the CWAB Awards 2014 hosted by CW Interiors, August 2014" href="images/awards/rk/cwab-awards2014-3.jpg"> </a>
                      <a class="venobox" data-gall="myGallery14" title="Mr. Rahul Kadri felicitated as India's Top 10 Inno-visionary Architects at the CWAB Awards 2014 hosted by CW Interiors, August 2014" href="images/awards/rk/cwab-awards2014-4.jpg"> </a>
                  </div>
                  <div class="Awards_Name">CWAB Awards <span>August 2014</span></div>
                </div>
             
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery19" title="Mr. Rahul Kadri felicitated at the IIID Conference,<br /> Baroda 2013" href="images/awards/rk/iid-conference-baroda-2013.jpg"> 
                        <img class="grayscale" src="images/awards/rk/iid-conference-baroda-2013.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name">IIID Conference Baroda <span>2013</span></div>
                </div>
              
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery15" title="Sona Group of Institution on the occasion of Golden Jubillee celebrations of Thiagarajar Polytechnic College and on Inauguration of R&D Center of Sona College of Technology honours Mr. Rahul Kadri, the architect of the project, by Honourable Dr. A.P.J. Abdul Kalam for raising their educational endeveavour into an architectural marvel. August 2009" href="images/awards/rk/sona-group-of-institution2009.jpg"> 
                        <img class="grayscale" src="images/awards/rk/sona-group-of-institution2009.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name">Sona Group of Institution <span>August 2009</span> </div>
                </div>
              
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery16" title="Kadri Consultants felicitated as India's Top 10 Architects at the CWAB Awards hosted by CWAB,<br /> August 2008" href="images/awards/rk/cwab-2008.jpg"> 
                        <img class="grayscale" src="images/awards/rk/cwab-2008.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name">CWAB Awards <span>2008</span></div>
                </div>
              
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery18" title="Mr. Rahul Kadri  felicitated by Indian Institute of Architect, <br />Solapur" href="images/awards/rk/iia-solapur.jpg"> 
                        <img class="grayscale" src="images/awards/rk/iia-solapur.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name"> IIA Solapur  <span>2004</span></div>
                </div>
             
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery17" title="Certificate of Merit awarded to Mr. I. M. Kadri Architects for being one of ‘India’s Top Innovisionary Architects’ at he Construction World Architects & Builders Awards 2004, Mumbai" href="images/awards/rk/construction-world-architects-2004.jpg"> 
                        <img class="grayscale" src="images/awards/rk/construction-world-architects-2004.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name">Construction World Architects - Builders Awards  <span>2004</span></div>
                </div>
             
                <div class="Awards_Box">
                  <div class="Awards_Thum">
                      <a class="venobox" data-gall="myGallery20" title="I.M.Kadri Architects felicitated by Indian Institute of Architect  Indian Institute of Architect, <br />Pune Center" href="images/awards/rk/iia-pune.jpg"> 
                        <img class="grayscale" src="images/awards/rk/iia-pune.jpg" alt="" />
                      </a>
                  </div>
                  <div class="Awards_Name"> IIA Pune</div>
                </div>
            

            </div>


           

          </div>
        </div>

        <div class="clr"></div>
      </div>

  </div>
</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      
<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>Master planning by architect in India</title>
<meta name="description" content="Approach To Urban Design And Master Planning" />
<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>
</head>

<body>

<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="active" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main_inner">
   <!--slider
    <div class="inner_banner">
       <img src="images/idealog/the-future-of-education-design-banner.jpg">
    </div>-->

    
    <div class="Inner_Page">
      <div class="breadcrumb mrg_btm top_bdr">
          <div class="container">
            <ul>
                <li><a href="index.php"><i class="fa_bedcrum fa-home" aria-hidden="true"></i></a></li>
                <li><a href="idealog.php">Idealog</a></li>
                <li>Creating Places Where People Thrive: IMK Architects’ Approach to Urban Design and Master-Planning </li>
            </ul>
          </div>
      </div>
      
      <div class="Idealog_Section">
        <div class="container">
          <h1 class="Title">Creating Places Where People Thrive: IMK Architects’ Approach to Urban Design and Master-Planning </h1>
          <div class="blog_date">Date: 14 April 2021.</div> <div class="author">Author: Rahul Kadri</div>
          <div class="Idealog_Container">
         

              <p>Architecture and design always exist within a larger urban, social and ecological milieu. And as a practitioner, one must be conscious of this context and respond to it in a manner beyond just the tectonic or aesthetic structuring of spaces and elements. Within large-scale master-planning and housing projects, this understanding of the intricate relationship between man and environment assumes critical relevance. How does a building or a series of buildings interact with the city? How do they relate to their immediate built or unbuilt surroundings? What are the natural energies available and how can they be tapped? Can architecture help shape neighbourhoods and promote community interaction? Can it influence health, behaviour, and patterns of living? What do people really value? What makes them happy? How can we create places where people thrive? </p>

              <div class="title">Planning for Self-Sufficiency </div>
              <p>Imagine a neighbourhood where you could access everything you need within a 500-metre radius from your doorstep – a self-sustaining unit with all public facilities and amenities available locally, from schools and hospitals to gardens and weekly farmer markets; a unit that could be administered with ease and where inhabitants would be able to walk or cycle to work, to learn, to shop, and to play. This principle is the foundation of all our work on campuses and townships; our architects identify a centre and plan all non-residential needs of the community within a walkable distance. Such ‘smart neighbourhoods’ reduce travel times and the need for regular inter-neighbourhood journeys, and by corollary, the high levels of carbon emissions and pollution in our cities today. They also ensure optimisation of resources and services, reduce wastage, and ensure effective costing. </p>

               <div class="col-sm-12">
                  <div class="thum"><img src="images/idealog/planning-for-self-sufficiency.jpg" alt="">
                    <p>Master-planning concepts that guided our designs for the JSW townships </p>
                  </div>
              </div>




              <div class="img_box">
                <div class="row">
                    <div class="col-sm-7">
                        <p><strong>Living in a Forest</strong></p>
                        <p>Research shows that humans have an innate affinity with the natural world – a concept known as biophilia ––and that the presence or absence of the elements of nature within our homes, offices, or schools, has a direct and measurable impact on our health and wellbeing. Our aim, therefore, is to always design spaces that are in harmony with their natural context. This can be achieved through optimal orientation of buildings to allow for natural light and ventilation; by building within the tree line, and creating connected green, open spaces and pedestrian corridors; and by providing spaces for occupants to grow their own food in private kitchen gardens or collective urban farms.</p>
                    </div>  
                    <div class="col-sm-5">
                        <div class="thum"><img src="images/idealog/living-in-a-forest.jpg" alt=""><p>IMK Architects’ design for the Vidyanagar Township in Bellary, Karnataka places emphasis on living in harmony with nature.</p></div>
                    </div>
                </div>
              </div>

               <div class="img_box">
                <div class="row">
                    <div class="col-sm-12">
                      <div class="title">Fostering Interaction </div>
                      <p>We aim to design communities that are dense enough to not only utilize resources and infrastructure effectively but allow people to be close to each other. To that end, we consciously design open, interactive spaces of varying sizes and scales for all kinds of users across age groups – from casual sit outs and smaller spaces for children to play to larger open grounds for sports and other recreational activities. This fosters community interaction and relations between neighbours and their families, leading to a sense of ownership and belonging and creating neighbourhoods that are filled with energy.</p>
                    </div>
                    <div class="col-sm-6">
                        <div class="thum"><img src="images/idealog/the-jsw-ratnagiri-township.jpg" alt="">
                          <p>The JSW Ratnagiri Township in Ratnagiri, Maharashtra, completed in 2010, was planned to create an identifiable and self-sufficient neighbourhood, which would promote social engagement and a sense of belonging.</p>
                        </div>
                    </div>  
                    <div class="col-sm-6">
                        <div class="thum"><img src="images/idealog/the-housing-clusters.jpg" alt="">
                          <p>The housing clusters in JSW Vidyanagar in Bellary, Karnataka are planned orthogonally along the North-South axis and have been staggered to create linear corridors of open spaces between that act as intimate landscaped areas for interaction. </p>
                        </div>
                    </div>
                </div>
              </div>


              <div class="img_box">
                <div class="row">
                    <div class="col-sm-12">
                      <div class="title">Eyes on the Street </div>
                      <p>Jane Jacobs’ concept of ‘eyes on the street’ is one of the cornerstones of modern urban theory -- vibrant street life is a crucial benchmark of perceived and real security within a neighbourhood. Maximizing perpendicular street junctions helps slow down traffic and create focal points of interest at such nodes in the form of plazas and landscaped spaces. </p>
                    </div>
                    <div class="col-sm-12">
                        <div class="thum"><img src="images/idealog/eyes-on-the-street.jpg" alt="">
                          <p>Our design for the township of JSW Ratnagiri draws from the concept of ‘eyes of the street’ and aims to enhance visual connection across the community; buildings are laid out compactly along the roads with safe and secure landscaped areas within the clusters</p>
                        </div>
                    </div>  
                </div>
              </div>
              
             

              <div class="title">Designing for Sustainability </div>

              <p>Sustainable neighbourhoods meet the diverse needs of existing and future residents, are sensitive to their environment, and contribute to a high quality of life. They are safe and inclusive, well-planned, -built and run, and offer equality of opportunity and good services to all. We approach sustainable design through the lens of the local context of the region. Our design for the built and the open takes from indigenous building materials, architectural language and climatic considerations. Our approach hinges on looking at sustainability from a holistic standpoint.</p>

              <p>Cultural Sustainability: Cultural sustainability focuses on the amenity of place. Put simply, if people are happy and enjoy their life, they will stay. Therefore, it is important to look at the complete life cycle from infancy to retirement, for families and single people. Designing a diversity of spaces is the key to making a place enjoyable. </p>
              <ul class="point">
                <li>Education facilities for all ages from pre-schoolers to adult education.</li>
                <li>Places for people to socialize from restaurants to neighbourhood parks. </li>
                <li>Quiet spaces for people to relax as well as lively spaces with a lot of activity.</li>
                <li>A diversity of entertainment options for people of different socio-economic levels.</li>
              </ul>

              <p>Economic Sustainability: A town cannot be sustainable without a stable economic base where wealth grows and opportunities are varied. A diversity of buildings, opportunities and businesses, therefore, is imperative to success.</p>
               <ul class="point">
                  <li>Entrepreneurship is to be encouraged, with a range of options: working at home, live-work units, and larger corporate or manufacturing spaces to facilitate future expansion. </li>
                  <li>Educational facilities are to be provided to help in personal development and the promotion of other businesses.</li>
                  <li>Retail spaces, both regional and neighbourhood, attract regional spenders to contribute to the local economy for longer.</li>
              </ul>

              <div class="img_box">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="thum"><img src="images/idealog/jsw-vidyanagar.jpg" alt="">
                          <p>JSW Vidyanagar, Bellary, Karnataka – Marketplace.</p>
                        </div>
                    </div>  
                    <div class="col-sm-6">
                        <div class="thum"><img src="images/idealog/jsw-hillside.jpg" alt="">
                          <p>JSW Hillside, Bellary, Karnataka – Primary School for the children of staff workers.</p>
                        </div>
                    </div>
                </div>
              </div>

              <p>Environmental sustainability: Environmental sustainability aims at conserving and/or efficiently utilising energy and water and contributes towards slowing done cataclysmic global effects. </p>

               <ul class="point">
                <li>Minimising the impact on the natural topography by building along the contours and retaining natural storm water drainage systems. </li>
                <li>Adopting sustainable water management and recycling across the township as well as the JSW steel plant. </li>
                <li>Recycling of waste.</li>
                <li>Introducing flora to control local climatic issues such as adding trees for shade. </li>
                <li>Conserving the natural plant and wild life for future generations.</li>
                <li>Sustainable architecture in terms of materials, energy use, shading devices and long-term adaptability.</li>
              </ul>




          </div>
        </div>

        <div class="clr"></div>
      </div>

  </div>
</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      

<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script>
</body>
</html>
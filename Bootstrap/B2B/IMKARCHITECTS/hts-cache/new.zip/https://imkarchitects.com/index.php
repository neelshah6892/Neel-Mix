<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>Top Architects in India for residential, hospital and school buildings </title>
<meta name="description" content="One of the best architecture firms in Mumbai & bangalore renowned for urban planning and design of resorts and healthcare buildings." />
<meta name="keywords" content="Top Architects In India, Top Architects In Mumbai, Top Architects In Bangalore, Best Architects In Mumbai, Best Architects In India" />
<meta name="google-site-verification" content="7DVx3SMwSBXQaOSMNM7ntsUNi-19UNfIdbxBOP24fIM" />
<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>

<link rel="canonical" href="https://imkarchitects.com/" />

<!-- slider -->
<link href="video-slider/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/homepg-media-queries.css" rel="stylesheet" type="text/css" />  
    
    
</head>

<body>

<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main">
   <!--slider-->
    <div id="banner" class="banner">

      <div id="homepage_slider" class="carousel slide">
        <ol class="carousel-indicators">
          <li data-target="#homepage_slider" data-slide-to="0" class="active"></li>
          <li data-target="#homepage_slider" data-slide-to="1"></li>
          <li data-target="#homepage_slider" data-slide-to="2"></li>
          <li data-target="#homepage_slider" data-slide-to="3"></li>
          <li data-target="#homepage_slider" data-slide-to="4"></li>
          <li data-target="#homepage_slider" data-slide-to="5"></li>
        </ol>

        <div class="carousel-inner">
          
          <div data-slide="0" class="item active">
            <img alt="lake palace hotel udaipur" src="images/slide7.jpg">
            <div class="text">
                <h3>malabar hills forest trails mumbai </h3>
                <p>The Elevated Forest trail was conceptualized for people to experience the Malabar Hill forest whilst still protecting the environment  which is the focal point. </p>
            </div>
          </div>

          <div data-slide="1" class="item">
            <img alt="symbiosis university hospital and research centre (suhrc) pune" src="images/slide1-new.jpg">
            <div class="text">
                <h3>symbiosis university hospital and research centre (suhrc) pune</h3>
                <p>Awarded Supreme Winner and Winner of Public Building Exterior Category at Surface Design Awards 2021</p>
            </div>
          </div>

          <div data-slide="2" class="item">
            <img alt="club mahindra tungi resort lonavala" src="images/slide2-new.jpg">
            <div class="text">
                <h3>club mahindra tungi resort lonavala</h3>
                <p>The Spa at Club Mahindra’s Tungi property uses simple lines and symmetry to create a calm and relaxing atmosphere. The central water body adds to the serenity of the space.</p>
            </div>
          </div>


          <div data-slide="3" class="item">
            <img alt="ceat mahal mumbai" src="images/slide3-new.jpg">
            <div class="text">
                <h3>ceat mahal mumbai</h3>
                <p>The architecture of Ceat Mahal has its roots in traditional Indian design, rich in form and proportion. The pioneer of Biophilic architecture</p>
            </div>
          </div>

          <div data-slide="4" class="item">
            <img alt="sona college of arts and sciences salem" src="images/slide4-new.jpg">
            <div class="text">
                <h3>sona college of arts and sciences salem</h3>
                <p>The design focuses on enhancing engagement –– between built forms and between students. An innovative facade which cuts the excess solar heat and direct sunlight</p>
            </div>
          </div>

          <div data-slide="5" class="item">
            <div class="slider-hide-on-mobile">
            <video id="bgvid" autoplay loop muted poster="images/slide6.jpg"><source src="images/proposal-for-dpu.mp4" type="video/mp4">Your browser does not support the video tag.</video>
              <div class="text">
                <h3>proposal for dpu – rural health training centre theur</h3>
                <p>A health training which is designed to avoid cross infections with various areas of sterility and enhancing the healing process of patients through biophilic architecture.</p>
            </div>
            </div>
          </div>

         
          

        </div> 

        <a class="carousel-control left" href="#homepage_slider" data-slide="prev">&lsaquo;</a>
        <a class="carousel-control right" href="#homepage_slider" data-slide="next">&rsaquo;</a>
      </div> 
      <div class="top_cat">
            <div id="arrow-down">
              <img src="images/btmt-arrwo.png" alt="" />
            </div>
        </div>
    </div> 

    <h1 class="tag_line">
      <div class="container">
        <i class="fa_quote4 fa-quote-left" aria-hidden="true"></i>
        DESIGNING PLACES WHERE PEOPLE THRIVE 
        <i class="fa_quote4_btm fa-quote-right" aria-hidden="true"></i>
      </div>
    </h1>

    <!--Section One-->
    <div class="Section_One">
        <div class="container">
            <div class="Title">To thrive, each space must be designed to be unique; recognising the users' highest aspirations </div>
            <div class="box_five">
             
                      <div class="box">
                        <h3 class="Title">cherish</h3>
                        <p>Places that are Beautiful, Biophilic, Memorable and Unique; that create a sense of belonging</p>
                      </div>
     
                      <div class="box">
                        <h3 class="Title">accomplish</h3>
                        <p>Places which nurture talent and allow for innovation and critical thinking facilitating people to achieve their goals, that are extremely functional</p>
                      </div>

                      <div class="box">
                        <h3 class="Title">engage</h3>
                        <p>Places where people can fully focus on their activities as well as interact and socialise with others</p>
                      </div>

                      <div class="box">
                        <h3 class="Title">relate</h3>
                        <p>Places where people can easily be social and make friends and create a sense of community</p>
                      </div>

                      <div class="box">
                        <h3 class="Title">meaning</h3>
                        <p>Places that are contextual, in character, material usage and form. In harmony with natural systems so as to minimize energy usage</p>
                      </div>
       

            
            </div>
        </div>
    </div>

    <!--Section Two-->
    <div class="Section_Two">
        <div class="container">
            <div class="Title"><img src="images/logobog.jpg" alt="" /></div>
            <div class="intro_text">since 1958</div>
            <div class="box_three">
              <div class="intro_text"><i class="fa_quote2 fa-quote-left" aria-hidden="true"></i><span>Our extensive experience allows us to</span>
<span>translate client vision into</span>
<span>beautiful Landmarks where</span>
<span>activities thrive and lives flourish.</span><i class="fa_quote2_btm fa-quote-right" aria-hidden="true"></i></div>
            </div>
        </div>
    </div>

     <div class="projects_statistics">
            <div class="container">
                <div class="row">
                  <div class="col-sm-3">
                    <div class="box">
                        <div class="thum"><img src="images/projects-icon.png" alt="" /></div>
                        <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='500' data-delay='8' data-increment="2">0</div>
                        <i data-wow-delay="4.1s" class="fa_plus fa-plus wow fadeIn" ></i>
                        <p> Projects <span>Designed</span></p>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="box">
                        <div class="thum"><img src="images/construction-area-icon.png" alt="" /></div>
                        <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='30' data-delay='10' data-increment="4">0</div>
                        <p> <span>Million Sq.Ft</span> Construction Area</p>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="box">
                        <div class="thum"><img src="images/cost-of-projects-icon.png" alt="" /></div>
                        <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='45' data-delay='8' data-increment="3">0</div>
                        <p><span>Billion Rupees</span> Cost of Projects </p>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="box">
                        <div class="thum"><img src="images/experience-of-years-icon.png" alt="" /></div>
                        <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='60' data-delay='5' data-increment="2">0</div>
                        <p> Years Of <span>Experience</span></p>
                    </div>
                  </div>

                </div>
            </div>
            <div class="sub_line">IMK is a multidisciplinary design practice</div>
            <div class="see_project"><a href="projects.php">See Projects<span><img src="images/right.png" alt="" /></span></a></div>
        </div>
    <!--Section Three-->
    <div class="Section_Three">
        <div>
            <!--<div class="Title">i m kadri architects</div>-->
            <div class="Sub_Title">expertise</div>
            <div class="intro_text">Our evolutionary processes and design principles have helped us achieve expertise in the following <span>disciplines. We have dedicated design studios for each one of them</span></div>
            <div class="row">
              <div class="col-sm-6">
                  <div class="expert_box">
                      <a href="self-redevelopment.php">
                      <img src="images/residential.jpg" alt="residential" class="grayscale" />
                      <div class="expert_containt">
                          <div class="box_con">
                            <h2 class="Title">residential self redevelopment</h2>
                          </div>
                      </div>
                      </a>
                  </div>
              </div>
              <div class="col-sm-6">
                  <div class="expert_box">
                    <a href="expertise-healthcare.php">
                      <img src="images/healthcare.jpg" alt="healthcare" class="grayscale" />
                      <div class="expert_containt">
                          <div class="box_con">
                            <h2 class="Title">healthcare</h2>
                          </div>
                      </div>
                      </a>
                  </div>
              </div>

              <div class="col-sm-6">
                  <div class="expert_box">
                    <a href="expertise-educational.php">
                      <img src="images/educational.jpg" alt="educational" class="grayscale" />
                      <div class="expert_containt">
                          <div class="box_con">
                            <h2 class="Title">educational</h2>
                          </div>
                      </div>
                      </a>
                  </div>
              </div>
              <div class="col-sm-6">
                  <div class="expert_box">
                    <a href="expertise-hospitality.php">
                      <img src="images/hospitality.jpg" alt="Hospitality" class="grayscale" />
                      <div class="expert_containt">
                          <div class="box_con">
                            <h2 class="Title">Hospitality</h2>
                          </div>
                      </div>
                      </a>
                  </div>
              </div>
            </div>

        </div>
    </div>

    <!--Section Five-->
    <div class="Section_Five">
        
        <div class="home_events">
          <h3 class="Title">Media</h3>
          <div class="container">

            <div class="clr"></div>
            <div class="row">
                <div class="col-sm-3">
                    <div class="home_news_box">
                        <div class="thub">
                          <a class="venobox" data-gall="myGallery" title="I.M. Kadri wins the Sir Mokshagundam Visvesvaraya Trophy Lifetime Achievement Award at CIDC Vishwakarma Awards March 2021" href="images/awards/cidc-vishwakarma.jpg"> 
            
                          <img src="images/cidc-vishwakarma-awards-thum.jpg" alt="" /></a>
                        </div>
                        <div class="home_news_des">I.M. Kadri wins the Sir Mokshagundam Visvesvaraya Trophy Lifetime Achievement Award at CIDC Vishwakarma Awards </div>
                        <div class="home_news_date">March, 2021 </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="home_news_box">
                        <div class="thub">
                           <a href="https://imkarchitects.com/images/publications/in-the-studio-with.pdf" target="_blank"> <img src="images/architect-and-interiors-india-april2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architect and Interiors India  | </div>
                        <div class="home_news_des">In the Studio With… Rahul Kadri</div>
                        <div class="home_news_date">April, 2021  </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="home_news_box">
                        <div class="thub">
                          <a href="https://www.thehindu.com/education/how-schools-and-colleges-need-to-revise-and-redesign-their-layouts-to-create-a-safe-environment/article34059112.ece" target="_blank"> <img src="images/publications/the-hindu-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Hindu | Rahul Kadri   </div>
                        <div class="home_news_des"> Prioritise safety and adaptability: How schools and colleges need to revise and redesign their layouts to create a safe environment</div>
                        <div class="home_news_date">March, 2021  </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="home_news_box">
                        <div class="thub">

                         <a class="iframe cboxElement" href="https://www.youtube.com/embed/bNcem9xqfDU?rel=0"><img src="images/future-of-design.jpg" alt="" />  <div class="play_btn"><i class="fa_youtube_play fa-youtube-play"></i></div></a>
                        </div>
                        <div class="mag_name">BW Event</div>
                        <div class="home_news_des">Business World Event - Future of Design</div>
                        <div class="home_news_date">April, 2021 </div>
                    </div>
                </div>
            </div>
            <div class="media_nav">
              <a href="awards.php">Awards</a> <a href="publications.php">Publications</a> <a href="events.php">Events</a> <a href="videos.php">Videos</a>
            </div>
          </div>
        </div>
    </div>

    <!--Section Four-->
    <div class="Section_Four">
        <div class="container">
          <h3 class="Title">Selected Clients</h3>

          <div id="slider3">
            <a class="prev3" href="#"><img src="images/left-arrwo.png" alt="" /></a> <a class="next3" href="#"><img src="images/right-arrwo.png" alt="" /></a>
              <div class="carousel-box row">
                  <div class="inner span12">
                      <div class="carousel main">
                          <ul>
                              <li>
                                  <a href="jsw-ratnagiri-school.php">
                                      <div class="testimony">
                                          <div class="client_thum"><img src="images/clients/jsw.png" alt="" />
                                          <div class="client_name">JSW Energy Limited</div>
                                      </div>
                                  </a>
                              </li>
                              <li>
                                  <a href="the-oberoi.php">
                                      <div class="testimony">
                                          <div class="client_thum"><img src="images/clients/the-east-india-hotels.png" alt="" />
                                          <div class="client_name">The East India hotels Ltd</div>
                                      </div>
                                  </a>
                              </li>
                              <li>
                                  <a href="tata-chemicals-babrala.php">
                                      <div class="testimony">
                                          <div class="client_thum"><img src="images/clients/tata-chemicals-limited.png" alt="" />
                                          <div class="client_name">Tata Chemicals Limited</div>
                                      </div>
                                  </a>
                              </li>
                              <li>
                                  <a href="reliance-guesthouse-at-sassan.php">
                                      <div class="testimony">
                                          <div class="client_thum"><img src="images/clients/reliance-power.png" alt="" />
                                          <div class="client_name">Reliance Power Ltd</div>
                                      </div>
                                  </a>
                              </li>
                              <li>
                                  <a href="taj-krishna.php">
                                      <div class="testimony">
                                          <div class="client_thum"><img src="images/clients/indian-hotels.png" alt="" />
                                          <div class="client_name">Taj Hotels Resorts and Palaces</div>
                                      </div>
                                  </a>
                              </li>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>

        </div>
    </div>


    


</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      
<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script>
<!--slider-->
<script src="owl-carousel/owl.carousel.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript" src="video-slider/bootstrap.min.js"></script>
<script type="text/javascript" src="video-slider/slider.js"></script>
<script id="rendered-js">
// without this script, the slider doesn't start on it's own:
!function ($) {
  $(function () {
    $('#homepage_slider').carousel();
   
        
  });
}(window.jQuery);


// if user chooses to not autoplay the video, the button should be uncommented in html and this script will make the button work:
var vid = document.getElementById("bgvid");
var playButton = document.querySelector("#slider-play-button button");

playButton.addEventListener("click", function () {
  if (vid.paused) {
    vid.play();
    playButton.classList.remove("play-video-button");
    playButton.classList.add("pause-video-button");
  } else {
    vid.pause();
    playButton.classList.add("play-video-button");
    playButton.classList.remove("pause-video-button");
  }
});
//# sourceURL=pen.js
    </script>
</body>
</html>
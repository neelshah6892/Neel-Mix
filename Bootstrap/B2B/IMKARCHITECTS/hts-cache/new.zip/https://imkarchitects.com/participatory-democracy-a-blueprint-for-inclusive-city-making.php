<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>Urban planning process for public projects</title>

<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>
</head>

<body>

<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="active" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main_inner">
   <!--slider-->
    <div class="inner_banner">
       <img src="images/idealog/blueprint.jpg">
    </div>

    
    <div class="Inner_Page">
      <div class="breadcrumb mrg_btm top_bdr">
          <div class="container">
            <ul>
                <li><a href="index.php"><i class="fa_bedcrum fa-home" aria-hidden="true"></i></a></li>
                <li><a href="idealog.php">Idealog</a></li>
                <li>Participatory Democracy: A Blueprint for Inclusive City-Making</li>
            </ul>
          </div>
      </div>
      
      <div class="Idealog_Section">
        <div class="container">
          <h1 class="Title">Participatory Democracy: A Blueprint for Inclusive City-Making</h1>
          <div class="blog_date">Date: 14 April 2021.</div> <div class="author">Author: Rahul Kadri</div>
          <div class="Idealog_Container">
         

              <p>The past few years have seen a slate of contentious urban development and public infrastructure projects in our country, which include the Sabarmati Riverfront in Ahmedabad, the redevelopment of the Central Vista in New Delhi, and the ongoing coastal road project in Mumbai. These projects may have a very significant and potentially irreversible impact on environment and ecology and also are, more importantly, based on questionable urban planning practises, having been conceptualised and/or realised without adequate consultation with the people most likely to be affected by them. 
               </p>

              <p>So what should the ideal planning process for public projects look like?</p>

              <div class="title">Participatory City-Making  </div>
              <p>The efficacy of any design and/or planning solution is based on the quality of questions asked and the seriousness with which they are answered. For a public project, the process must begin with three crucial questions. First, who are the stakeholders in the project? Second, what are their needs and aspirations? What features do they truly value and why? And third, what is the order of importance of these features for the stakeholders and why? </p>

             
             <p><strong>1.  Identification of Stakeholders</strong>: The stakeholder pool should include:</p>
               <ul class="point">
                  <li>People already living and/or working off the land to be developed.</li>

                  <li>People living in the adjacent areas who would be impacted by its extraneous activities – activities that would impact the existing infrastructure and replace the green cover of land around them.</li> 

                  <li>The stakeholder pool must also include experts from various disciplines like urban planning, landscape designing, transportation, environment, land surveying etc.</li>
              </ul>


             <p><strong>  2. The SCRUM Process </strong></p>
             <p><em>(SCRUM: an agile framework/process of work first formalized for software development projects, but works well for any complex, innovative scope of work.)</em></p>
             <p>(a) <strong>Public Ward Meetings</strong>: Once the stakeholders are identified, all of them must be consulted through open and transparent, neighbourhood-level public workshops or meetings, with each ward divided into about ten neighbourhoods. There are many frameworks available to run these meetings effectively. One such framework that has proven effective and emphasizes teamwork, accountability and iterative progress toward a well-defined goal is the SCRUM workshop process:</p>

              <ul class="point">
                <li>Citizen stakeholders and various experts can be invited to the meetings through pamphlets and newsletters sent by their respective RWA societies. The use of social media platforms such as Facebook and LinkedIn as well as Whatsapp groups can be used as effective tools in spreading awareness. Clear information about the project, timeline, process and budget along with the project’s potential short term and long-term impacts must be provided — allowing citizens to come prepared to the meeting with ideas, concerns and suggestions. Such transparency would also help gain the trust of the citizens.</li>
               
                <li>Assuming about one hundred residents show up to each meeting, the features requested by them can be recorded and enlisted on a whiteboard.</li>
              </ul>

              <p><strong> (b) Prioritizing Features and Drafting a Strategic Brief:</strong></p>
        
             
              <ul class="point">
                <li>These features can be prioritised in as short as three hours through a rating/ voting system that hinges on a simple question put to the residents themselves: How important is this particular feature to you and the city? The needs of the current occupants of the land parcel in question and the people directly dependent on it for their livelihood would be prioritised over the needs of the people living in adjacent neighbourhoods or wards. The aim is to maximize happiness for the largest number of people. And the 80/20 principle that 20% of the features will give you 80% of the happiness.</li> 

                <li>The priority of each feature should be determined by the percentage of the stakeholder pool it affects.</li> 

                <li>The product of this elaborate exercise is a strategic design and/or planning brief – a thorough list of stakeholder requirements and expectations from the project ordered by importance.</li> 
              </ul>

              <p><strong>3.  Design Competition</strong>:</p>
              <p> The municipal body should then hold a design competition based on guidelines laid down by The Council of Architecture, a statutory body constituted by the Government of India under the provisions of the Architects Act, 1972, inviting architects,<a href="https://imkarchitects.com/urban-design-and-town-planning.php"> urban designers and planners</a>, and landscape architects etc. to submit proposals that address the strategic brief. </p>
              <ul class="point">
                <li>An independent jury panel consisting of 8-10 members must be composed of qualified experts from varied domains such as architecture, urban planning, landscape design, transportation, environment etc., as well as eminent citizens and representatives of the government.</li> 

                <li>The jury panel can lay down specific qualifications for the entrants to help filter out entries.</li> 

                <li>Entrants should strictly follow the strategic brief and design guidelines for the project.</li> 

                <li>Once proposals are received, the jury should judge them against parameters including:
                  <ul> 
                      <li>a)  How well does the design address the most important features that the stakeholders value?</li>
                      <li>b) What short-term and long-term impacts does the proposal have?</li>
                      <li>c)  What steps does it include to safeguard environmental concerns and address concerns of minority groups?</li>
                  </ul>
                </li> 
                <li>This jury panel could prequalify about five shortlisted proposals for public exhibition to the citizens before the final judging is completed in an open forum to ensure transparency. Both the shortlisted and the comments received from the jury on these proposals must also be published on public forums for the viewership and deliberations from citizens at large.</li> 
              </ul>

              <div class="title">Global Precedents </div>

              <p>There are several international precedents that demonstrate how citizen participation can yield better, more relevant and effective solutions for communities. They elucidate how strategic and well-thought-out planning processes are imperative to the success of such projects:</p>


              <div class="img_box">
                <div class="row">
                   
                    <div class="col-sm-6">
                        <p><strong>1.   Central Park, New York</strong></p>
                        <p>Widely known as the “crown jewel of New York”, Central Park is a vibrant and enduring urban space for New Yorkers and one of the world’s most admired parks. The vision, innovation and engineering behind its creation followed a democratic process. Planning commenced with the country’s first landscape design contest in 1983 which was hosted by the Central Park Commission. Frederick Law Olmsted and Calvert Vaux's "Greensward Plan" was selected as the winning design from a pool of 33 entries. Three other plans were announced as runners-up and featured in a city exhibit.</p>
                        <p><a href="https://blogs.oracle.com/construction-engineering/construction-of-central-park-a-marvel-of-public-planning-and-project-delivery-innovation" target="_blank">Read More</a></p>
                    </div>  
                     <div class="col-sm-6">
                        <div class="thum"><img src="images/idealog/central-park.jpg" alt=""><p>Creator: ©Andrew Bertuleit | Credit: Getty iStockphoto</p></div>
                        
                    </div>
                </div>
              </div>

              <div class="img_box">
                <div class="row">
                    
                    <div class="col-sm-6">
                        <p><strong>2. Park Am Gleisdreieck, Berlin</strong></p>
                        <p>In the heart of Kreuzberg, Berlin’s new, 26-hectare inner-city park, Park am Gleisdreieck evolved from an inaccessible wasteland to a favourite place for Berliners and tourists of all ages. Designed by Atelier Loidl, the previous freight and mail railyard was redeveloped into a public park that offers a contemplative and free space to be one with nature. From the onset of the design process, citizens’ wishes and ideas were included in planning and creating the park – intensive exchange of views and ideas from future users via household surveys, online dialogues and local events. Today, the park conserves the free-spirit and historic culture of the city and is truly representative of the people’s aspirations.</p>
                        <p><a href="https://landezine-award.com/park-am-gleisdreieck/" target="_blank">Read More</a></p>
                    </div> 
                    <div class="col-sm-6">
                        <div class="thum"><img src="images/idealog/park-am-gleisdreieck.jpg" alt=""><p>Credit: ©www.publicspace.org</p></div>
                        
                    </div> 
                </div>
              </div>

              <div class="img_box">
                <div class="row">
                    
                    <div class="col-sm-6">
                        <p><strong>3. The High Line, New York</strong></p>
                        <p>The story of New York City’s High Line, a 2.3-kilometre-long elevated park created on a disused railroad track, is an inspiring one. Friends of the High Line, an organisation that initially came together as a citizen interest group to save the historic structure from demolition, ended up working closely with the city government to fund and realise the project. Today, it also maintains and manages the park, which has revitalised the neighbourhood and blossomed into a vibrant public space for the city at large.</p>
                        <p><a href="https://www.thehighline.org/about/" target="_blank">Read More</a></p>
                    </div>  
                    <div class="col-sm-6">
                        <div class="thum"><img src="images/idealog/the-high-line.jpg" alt=""> <p>Credit: ©Iwan Baan, 2014</p></div>
                       
                    </div>
                </div>
              </div>

              <div class="title">Imagining a New Future </div>

              <p>I believe that it is imperative for all public projects to truly be representative of the needs and aspirations of the cities and the people that they serve. For instance, the eastern waterfront of Mumbai where 1800 acres of land is available for redevelopment should be planned through a similar inclusive process. Participation of citizens is key to creating a shared future. This is how we can ensure that the city’s land and resources are used effectively and appropriately – with the needs and concerns of all stakeholders in mind and for their maximum benefit. This could, and should, become the blueprint for a more inclusive model of urbanism for Indian cities.</p>




          </div>
        </div>

        <div class="clr"></div>
      </div>

  </div>
</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      

<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>I M Kadri</title>

<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>
</head>

<body>

<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="active" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main_inner">

    
    <div class="Inner_Page">
      <div class="breadcrumb mrg_btm top_bdr">
        <div class="container">
          <ul>
              <li><a href="index.php"><i class="fa_bedcrum fa-home" aria-hidden="true"></i></a></li>
              <li><a href="projects.php">Projects</a></li>
              <li>Community Development</li>
          </ul>
        </div>
      </div>
      <div>
        <div class="projects_wrap">
            <div class="row">
              <div class="col-sm-2">
                <div class="projects_box">
                    <div class="thum">
                      <a href="nepean-sea-road.php">
                        <img src="images/projects/community-development/nepean-sea-road.jpg" alt="Nepean Sea Road Street Revamp" />
                      <div class="projects_name">
                        <div class="namec">Nepean Sea Road Street Revamp<span>Nepean Sea Road</span></div>
                      </div>
                      </a>
                    </div>
                </div>
              </div>
              <div class="col-sm-2">
                <div class="projects_box">
                    <div class="thum">
                      <a href="wadala-regeneration-project.php">
                        <img src="images/projects/community-development/wadala-regeneration-project.jpg" alt="Wadala Regeneration Project" />
                        <div class="projects_name">
                          <div class="namec">Wadala Regeneration Project<span>Wadala</span> </div>
                        </div>
                      </a>
                    </div>
                </div>
              </div>
               <div class="col-sm-2">
                <div class="projects_box">
                    <div class="thum">
                      <a href="malabar-hill-forest-trails.php">
                        <img src="images/projects/community-development/malabar-hill-forest-trails.jpg" alt="Malabar Hill Forest Trails" />
                        <div class="projects_name">
                          <div class="namec">Malabar Hill Forest Trails<span>Malabar Hill, Mumbai</span> </div>
                        </div>
                      </a>
                    </div>
                </div>
              </div>
              


            </div>
        </div>
      </div>
    </div>

</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      

<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script>
</body>
</html>
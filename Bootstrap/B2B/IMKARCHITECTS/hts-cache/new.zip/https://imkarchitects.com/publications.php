<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>I M Kadri</title>


<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>
</head>

<body>

<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="active" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main_inner">
   <!--slider
    <div class="inner_banner">
       <img src="images/inner-banner.jpg">
       <div class="banner_text">
          <div class="Title"> Team</div>
      </div>
    </div>
-->
    
    <div class="Inner_Page">
      <div class="breadcrumb mrg_btm top_bdr">
          <div class="container">
            <ul>
                <li><a href="index.php"><i class="fa_bedcrum fa-home" aria-hidden="true"></i></a></li>
                <li><a href="#">media</a></li>
                <li>Publications</li>
            </ul>
          </div>
      </div>
      
      <div class="Publications_Section">
        <div class="container">
          <h1 class="Title">Publications</h1>
          <div class="row">
              <div id="content">
                  <!--Page 2-->
                  <section>
                    <div class="Publications_Row">
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/focus-on-creating-holistic-experiences.pdf" target="_blank"> <img src="images/publications/bw-hotelier-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">BW Hotelier | Rahul Kadri  </div>
                        <div class="artical_name">Focus on Creating Holistic Experiences</div>
                        <div class="artical_date">June, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://timesproperty.com/news/post/how-can-mumbai-be-more-resilient-during-monsoon-blid866" target="_blank"> <img src="images/publications/times-property-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Times Property | Rahul Kadri  </div>
                        <div class="artical_name">How Can Mumbai be More Monsoon Resilient</div>
                        <div class="artical_date">June, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.archdaily.com/962140/symbiosis-university-hospital-and-research-centre-imk-architects" target="_blank"> <img src="images/publications/arch-daily-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Arch Daily |   </div>
                        <div class="artical_name">Symbiosis University Hospital & Research Centre (SUHRC), IMK Architects</div>
                        <div class="artical_date">June, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/flooring-solutions-healthcare.pdf" target="_blank"> <img src="images/publications/construction-world-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Construction World | Nithin Hosabettu  </div>
                        <div class="artical_name">Feature: Flooring Solutions Healthcare: Symbiosis University Hospital & Research Centre (SUHRC)</div>
                        <div class="artical_date">June, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://de51gn.com/what-do-indias-covid-19-affected-cities-need-the-countrys-leading-architects-propose-solutions/" target="_blank"> <img src="images/publications/de51gn-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">De51gn |  </div>
                        <div class="artical_name">What do India’s Covid-19 affected cities need? The country’s leading architects propose solutions</div>
                        <div class="artical_date">June, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.architecturaldigest.in/story/imk-architects-share-a-vision-for-the-slums-in-mumbai-at-the-london-design-biennale/" target="_blank"> <img src="images/publications/architectural-digest-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architectural Digest | Gauri Kelkar</div>
                        <div class="artical_name">IMK Architects share a vision for the slums in Mumbai, at the London Design Biennale</div>
                        <div class="artical_date">June, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://thedailyguardian.com/adoption-of-sustainable-design-practices-is-the-need-of-the-hour/" target="_blank"> <img src="images/publications/the-daily-guardian-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Daily Guardian | Noor Anand Chawla</div>
                        <div class="artical_name">Adoption of Sustainable Design Practices is the need of the Hour</div>
                        <div class="artical_date">June, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.indiatoday.in/cities/mumbai/story/mumbai-first-treetop-walk-malabar-hill-by-year-end-1810846-2021-06-04" target="_blank"> <img src="images/publications/india-today-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">India Today | Mustafa Shaikh</div>
                        <div class="artical_name">Mumbai to get first ‘treetop’ walkway at Malabar Hill by year end</div>
                        <div class="artical_date">June, 2021 </div>
                      </div>

                       <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/bmc-runs-with-malabar-hill-canopy.pdf" target="_blank"> <img src="images/publications/times-of-india-june2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Times of India |  </div>
                        <div class="artical_name">BMC Runs with Malabar Hill Canopy</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.architectandinteriorsindia.com/projects/19659-balador-athena-a-sanctuary-for-green-living" target="_blank"> <img src="images/publications/balador-athena-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architecture & Interiors India | </div>
                        <div class="artical_name">Balador Athena – A Sanctuary for Green Living</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.thebetterindia.com/255707/mumbai-imk-architect-pune-symbiosis-hospital-low-cost-passive-cooling-jaali-bricks-ecofriendly-sustainable-india-gop94/" target="_blank"> <img src="images/publications/the-better-india-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Better India | Gopi Karelia  </div>
                        <div class="artical_name">Mumbai Architect’s Award-Winning Hospital Design Using Jalis Saves up to 80% Energy</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.tribuneindia.com/news/health/2-metres-social-distancing-not-enough-as-covid-airborne-258251" target="_blank"> <img src="images/publications/the-tribune-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Tribune |  </div>
                        <div class="artical_name">2 meters social distancing not enough as Covid airborne</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="http://www.businessworld.in/article/Bringing-The-Connection-With-Nature-Back/23-05-2021-390618/" target="_blank"> <img src="images/publications/business-world-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Business World |  </div>
                        <div class="artical_name">Bringing The Connection With Nature Back</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://ifj.co.in/ifj-likes/landscaped-courtyard-for-pune-housing-complex/" target="_blank"> <img src="images/publications/ifj-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">IFJ |  </div>
                        <div class="artical_name">Landscaped courtyard for Pune housing Complex</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/building-with-might.pdf" target="_blank"> <img src="images/publications/home-design-trends-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Home & Design Trends | Tina Thakrar  </div>
                        <div class="artical_name">Building with Might</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/ar-i-m-kadri-honoured-with-ifetime-achievement-award-by-cidc.pdf" target="_blank"> <img src="images/publications/ifj-news-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">IFJ News |  </div>
                        <div class="artical_name">Ar. I. M. Kadri Honoured with Lifetime Achievement Award by CIDC</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/shaping-holistic-learning-environments.pdf" target="_blank"> <img src="images/publications/architecture-design-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architecture + Design | Rahul Kadri  </div>
                        <div class="artical_name">Architecture for Education: Shaping Holistic Learning Environments</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.mgsarchitecture.in/building-materials-products/articles/2969-ar-rahul-kadri-imk-architects.html" target="_blank"> <img src="images/publications/mgs-architecture-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">MGS Architecture |  </div>
                        <div class="artical_name">Ar. Rahul Kadri, IMK Architects</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>


                    </div>

                  </section>

                  <!--Page 3-->
                  <section>
                    <div class="Publications_Row">
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.healthcareradius.in/projects/29129-a-biophilic-hospital-design-marvel" target="_blank"> <img src="images/publications/healthcare-radius-may2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Healthcare Radius  |</div>
                        <div class="artical_name">A biophilic hospital design marvel</div>
                        <div class="artical_date">May, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/in-the-studio-with.pdf" target="_blank"> <img src="images/publications/architect-and-interiors-apr2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architect and Interiors India |</div>
                        <div class="artical_name">In the Studio With…  Rahul Kadri</div>
                        <div class="artical_date">April, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/architects-are-pushing.pdf" target="_blank"> <img src="images/publications/construction-world-apr2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Construction World |</div>
                        <div class="artical_name">The ‘Cover’ Story: Architects are pushing the boundaries on roofing & cladding despite financial and availability constraints</div>
                        <div class="artical_date">April, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/mokshagundam-visvesvaraya-trophy.pdf" target="_blank"> <img src="images/publications/architecture-design-apr2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architecture + Design |</div>
                        <div class="artical_name">I.M. Kadri Awarded the Sir Mokshagundam Visvesvaraya Trophy</div>
                        <div class="artical_date">April, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/renowned-architect.pdf" target="_blank"> <img src="images/publications/commercial-design-apr2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Commercial Design |</div>
                        <div class="artical_name">Renowned Architect I.M. Kadri Honoured with Lifetime Achievement Award by CIDC</div>
                        <div class="artical_date">April, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/rebuilding-the-world.pdf" target="_blank"> <img src="images/publications/india-today-apr2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">India Today | Ridhi Kale</div>
                        <div class="artical_name">Rebuilding the World</div>
                        <div class="artical_date">April, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.designdekko.com/blog/can-empathic-design-heal-our-cities" target="_blank"> <img src="images/publications/design-dekko-apr2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Design Dekko |</div>
                        <div class="artical_name">Can Empathic Design Heal Our Cities? Is designing with empathy the key to reviving and revitalizing our urban centres?</div>
                        <div class="artical_date">April, 2021 </div>
                      </div>
                      
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.surfacesreporter.com/articles/82436/the-way-to-success-how-a-women-with-hope-resilience-and-power-made-it-to-the-top" target="_blank"> <img src="images/publications/surfaces-reporter-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Surfaces Reporter |</div>
                        <div class="artical_name">The Way to Success: How A Woman with Hope, Resilience and Power Made it to the Top: Meet Anuprita Dixit</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.tradelinkmedia.biz/publications/6/news/2707" target="_blank"> <img src="images/publications/southeast-asia-building-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Southeast Asia Building |</div>
                        <div class="artical_name">IMK Architects win at Surface Design Awards 2021, London </div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.thehindu.com/education/how-schools-and-colleges-need-to-revise-and-redesign-their-layouts-to-create-a-safe-environment/article34059112.ece" target="_blank"> <img src="images/publications/the-hindu-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Hindu | Rahul Kadri</div>
                        <div class="artical_name">Prioritise safety and adaptability: How schools and colleges need to revise and redesign their layouts to create a safe environment</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.thedesigncollective.co.in/tdcinterviews-architectrahulkadri" target="_blank"> <img src="images/publications/the-design-collective-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Design Collective |</div>
                        <div class="artical_name">Interviews: Rahul Kadri: talks about his architectural journey  and how he took over the reigns from his father</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.healthcareradius.in/projects/28501-symbiosis-hospital-wins-prestigious-international-design-award" target="_blank"> <img src="images/publications/healthcare-radius-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Healthcare Radius |</div>
                        <div class="artical_name">Symbiosis Hospital wins prestigious International Design Award</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://mumbai.citizenmatters.in/why-mumbai-slums-cant-self-redevelop-housing-crisis-23282" target="_blank"> <img src="images/publications/citizen-matters-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Citizen Matters | Rahul Kadri</div>
                        <div class="artical_name">Why Mumbai housing societies can’t self-redevelop anymore</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://epaper.hindustantimes.com/Home/ShareArticle?OrgId=93bf4c347c&imageview=0" target="_blank"> <img src="images/publications/hindustan-times-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Hindustan Times | Rahul Kadri</div>
                        <div class="artical_name">Remote working is the most efficient way</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/biophilic-interactive-design.pdf" target="_blank"> <img src="images/publications/architecture-design-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architecture + Design |</div>
                        <div class="artical_name">Biophilic, Interactive Design</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/weaving-magic.pdf" target="_blank"> <img src="images/publications/commercial-design-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Commercial Design |</div>
                        <div class="artical_name">Case Study: Weaving Magic with Bricks!</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.99acres.com/articles/womens-day-the-pandemic-has-encouraged-us-to-reinvent-ourselves.html" target="_blank"> <img src="images/publications/99-acres-mar2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">99 Acres | Anuprita Dixit</div>
                        <div class="artical_name">Women’s Day: The pandemic has encouraged us to reinvent ourselves</div>
                        <div class="artical_date">March, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://wfmmedia.com/imk-architects-leading-architecture-and-urban-design/" target="_blank"> <img src="images/publications/wfm-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Windows & Façade Magazine |</div>
                        <div class="artical_name">IMK Architects Win Top Awards at Surface Design Awards 2021, London</div>
                        <div class="artical_date">February, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.99acres.com/articles/why-maharashtras-self-redevelopment-scheme-needs-a-financial-lifeline.html" target="_blank"> <img src="images/publications/99acres-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">99 Acres | Rahul Kadri</div>
                        <div class="artical_name">Why Maharashtra’s self-redevelopment scheme needs a financial lifeline?</div>
                        <div class="artical_date">February, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/architect-of-the-month.pdf" target="_blank"> <img src="images/publications/india-today-home-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">India Today Home | Ridhi Kale</div>
                        <div class="artical_name">Architect of the Month: Rahul Kadri. </div>
                        <div class="artical_date">February, 2021 </div>
                      </div>
                     
                    </div>
                  </section>

                  <!--Page 4-->
                  <section>
                    <div class="Publications_Row">

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/citymakers.pdf" target="_blank"> <img src="images/publications/construction-world-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Construction World | Rahul Kadri</div>
                        <div class="artical_name">Citymakers: Call for Action! Post pandemic, we must plan our cities to be more resilient and responsive to future crises </div>
                        <div class="artical_date">February, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.architectandinteriorsindia.com/14743-imk-architects-win-at-surface-design-awards-2021-london" target="_blank"> <img src="images/publications/architecture-interiors-india-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architecture & Interiors India |</div>
                        <div class="artical_name">IMK Architects win at Surface Design Awards 2021, London</div>
                        <div class="artical_date">February, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.commercialdesignindia.com/projects/8035-imk-architects-win-at-surface-design-awards-2021-london-for-the-symbiosis-university-hospital-and-research-centre" target="_blank"> <img src="images/publications/commercial-design-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Commercial Design |</div>
                        <div class="artical_name">IMK Architects win at Surface Design Awards 2021, London, for the Symbiosis University Hospital and Research Centre</div>
                        <div class="artical_date">February, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://homedesignerandarchitect.co.uk/2021/02/12/symbiosis-university-hospital-by-imk-architects-named-supreme-winner-at-surface-design-awards-2021-surfacethinking/" target="_blank"> <img src="images/publications/homedesignerandarchitect-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Home Designer & Architect |</div>
                        <div class="artical_name">Symbiosis University Hospital by IMK Architects named Supreme Winner at Surface Design Awards 2021</div>
                        <div class="artical_date">February, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/livingetc-maria-louis-feb2021.pdf" target="_blank"> <img src="images/publications/livingetc-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Livingetc | Maria Louis</div>
                        <div class="artical_name">Design Profile: Ar. Rahul Kadri</div>
                        <div class="artical_date">February, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.archdaily.com/956189/auric-hall-imk-architects" target="_blank"> <img src="images/publications/archdaily-feb2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Archdaily | IMK Architects</div>
                        <div class="artical_name">Auric Hall, IMK Architects</div>
                        <div class="artical_date">February, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/building-a-house-jan21.pdf" target="_blank"> <img src="images/publications/the-economic-jan2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name" style="font-size:12px;">The Economic Times - Wealth | Narendra Nathan </div>
                        <div class="artical_name">Building a house? Here are 6 ways to reduce construction costs</div>
                        <div class="artical_date">January, 2021 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/ad-jan21.pdf" target="_blank"> <img src="images/publications/architecture-design-jan2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architecture + Design |</div>
                        <div class="artical_name">A timeless modern landmark inspired by the city’s heritage: Auric Hall</div>
                        <div class="artical_date">January, 2021 </div>
                      </div>
 
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.mgsarchitecture.in/architecture-design/projects/2857-expressing-grandeur-solidarity.html" target="_blank"> <img src="images/publications/mgs-architecture-jan2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">MGS Architecture |</div>
                        <div class="artical_name">Expressing Grandeur & Solidarity: Symbiosis Hospital & Research Center</div>
                        <div class="artical_date">January, 2021 </div>
                      </div>
              
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://inhabitat.com/past-and-future-come-together-at-the-sustainable-auric-hall/" target="_blank"> <img src="images/publications/inhabitat-jan2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">INHABITAT | KC Morgan </div>
                        <div class="artical_name">Past and future come together at the sustainable  Auric Hall</div>
                        <div class="artical_date">January, 2021 </div>
                      </div>
               
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/ifj-auric-hall.pdf" target="_blank"> <img src="images/publications/ifj-jan2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">IFJ | IMK Architects </div>
                        <div class="artical_name">Auric Hall, Aurangabad</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/ifj-a-change for-the-better.pdf" target="_blank"> <img src="images/publications/ifj-focus-jan2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">IFJ | Aadrita Chatterji </div>
                        <div class="artical_name">A Change for the Better</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://realtyplusmag.com/mumbai-megacity-urban-growth/" target="_blank"> <img src="images/publications/realty-jan2021.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Realty+ | Sapna Srivastava </div>
                        <div class="artical_name">Mumbai Megacity Urban Growth</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.financialexpress.com/money/what-is-maharashtras-self-redevelopment-scheme-for-housing-societies-and-why-it-needs-a-financial-lifeline/2156823/" target="_blank"> <img src="images/publications/financial-express-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Financial Express | Rahul Kadri </div>
                        <div class="artical_name">What is Maharashtra’s self-redevelopment scheme for housing societies and why it needs a financial lifeline</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                 
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://mumbai.citizenmatters.in/possible-alternatives-for-mumbai-slums-in-a-post-covid-19-world-22119" target="_blank"> <img src="images/publications/citizen-matters-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Citizen Matters | Rahul Kadri </div>
                        <div class="artical_name">Possible Alternatives for Mumbai Slums in a Post-COVID-19 World</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                 
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://media.biltrax.com/imk-architects-hospitals-then-and-now/" target="_blank"> <img src="images/publications/biltrax-media-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Biltrax Media | Twinkle Tolani </div>
                        <div class="artical_name">IMK Architects: Hospitals Then and Now</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                    </div>
                  </section>

                  <!--Page 5-->
                  <section>
                    <div class="Publications_Row">
          
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://thewire.in/environment/coastal-road-project-damage-environment-outdated" target="_blank"> <img src="images/publications/the-wire-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Wire | Rahul Kadri </div>
                        <div class="artical_name">Coastal Road Projects Don't Just Damage the Environment – They Are Also Outdated</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://hospitality.economictimes.indiatimes.com/news/operations/architecture-and-design/the-future-of-hotel-buildings/79676309" target="_blank"> <img src="images/publications/et-hospitality-world-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">ET Hospitality World | Sakshi Singh </div>
                        <div class="artical_name">The Future of Hotel Buildings</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/facade-fire-mitigation.pdf" target="_blank"> <img src="images/publications/windows-and-facade-magazine-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Windows & Facade Magazine | </div>
                        <div class="artical_name">Facade Fire Mitigation: The need for a Comprehensive Approach</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/glass-provides-a-transparency.pdf" target="_blank"> <img src="images/publications/ace-update-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">ACE Update  | </div>
                        <div class="artical_name">Glass provides a transparency without creating a sense of enclosure</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/a-sustainable-future.pdf" target="_blank"> <img src="images/publications/architecture-design-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architecture + Design | Rahul Kadri </div>
                        <div class="artical_name">A Sustainable Future for Healthcare Design</div>
                        <div class="artical_date">December, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.architectandinteriorsindia.com/insights/13456-the-pandemic-demands-critical-changes-in-how-we-plan-and-design-cities-writes-rahul-kadri" target="_blank"> <img src="images/publications/architect-and-interiors-india-dec2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architect & Interiors India | Rahul Kadri </div>
                        <div class="artical_name">The pandemic demands critical changes in how we plan and design cities, writes Rahul Kadri</div>
                        <div class="artical_date">November, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.constructionweekonline.in/projects-tenders/15891-auric-hall-the-new-face-of-aurangabad" target="_blank"> <img src="images/publications/construction-week-online-23rd-november-2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Construction Week Online | </div>
                        <div class="artical_name">Auric Hall: The new face of Aurangabad</div>
                        <div class="artical_date">November, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://mumbaimirror.indiatimes.com/mumbai/other/building-for-the-future/articleshow/79340254.cms" target="_blank"> <img src="images/publications/mumbai-mirror-22nd-november-2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Mumbai Mirror | Suktara Ghosh </div>
                        <div class="artical_name">Building for the Future</div>
                        <div class="artical_date">November, 2020 </div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.newindianexpress.com/cities/delhi/2020/nov/25/learning-at-new-normal-revamping-schools-for-a-post-covid-world-2227655.html" target="_blank"> <img src="images/publications/the-indian-express-25th-november-2020.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The New Indian Express | </div>
                        <div class="artical_name">Learning at new normal: Revamping schools for a post-COVID world</div>
                        <div class="artical_date">November, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/the-morning-standard-25th-november-2020.pdf" target="_blank"> <img src="images/publications/the-morning-standard-25th-november-2020_s.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Morning Standard | </div>
                        <div class="artical_name">Schools in the Post COVID World</div>
                        <div class="artical_date">November, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/urban-planning-realty.pdf" target="_blank"> <img src="images/publications/urban-planning.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Realty+ | </div>
                        <div class="artical_name">Urban Planning and Changing Design Sensibilities</div>
                        <div class="artical_date">october, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.houzz.in/magazine/retrospective-the-unprecedented-architectural-contribution-of-im-kadri-stsetivw-vs~94267299" target="_blank"> <img src="images/publications/unprecedented-architectural.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Houzz | Meghna Mehta </div>
                        <div class="artical_name">Retrospective: The Unprecedented Architectural Contribution of IM Kadri</div>
                        <div class="artical_date">November, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.stirworld.com/see-features-civic-building-auric-hall-stands-as-the-face-of-an-upcoming-city-in-india" target="_blank"> <img src="images/publications/civic-building.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Stir World | Ankitha Gattupalli </div>
                        <div class="artical_name">Civic building Auric Hall stands as the face of an upcoming city in India</div>
                        <div class="artical_date">october, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.jasubhaimedia.com/iab/2020/august-2020/#p=34" target="_blank"> <img src="images/publications/ia-and-b.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">IA&B | IMK Architects </div>
                        <div class="artical_name">Holistic Healing Spaces <br />Symbiosis Hospital and Research Center (SUHRC)</div>
                        <div class="artical_date">August, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/realty.pdf" target="_blank"> <img src="images/publications/realty.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Realty+ | Priya Saini </div>
                        <div class="artical_name">Architecture Going Local From Global</div>
                        <div class="artical_date">september, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/midday.pdf" target="_blank"> <img src="images/publications/midday.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Midday | Anju Maskeri </div>
                        <div class="artical_name">To Beat Coronavirus That's Weaker Outdoors, Mumbai Must Go Al Fresco: Experts</div>
                        <div class="artical_date">october, 2020 </div>
                      </div>
                    </div>
                  </section>

                  <!--Page 6-->
                  <section>

                    <div class="Publications_Row">
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://timesofindia.indiatimes.com/life-style/home-garden/traditional-indian-craft-inspires-modern-interiors-designers-for-sustainable-architecture/articleshow/78591173.cms" target="_blank"> <img src="images/publications/traditional-indian-craft.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Times of India – Entertainment Times</div>
                        <div class="artical_name">Traditional Indian Craft Inspires Modern Interiors Designers For Sustainable Architecture</div>
                        <div class="artical_date">october, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://scroll.in/article/972781/the-vision-of-slum-free-indian-cities-needs-to-be-viewed-through-the-lens-of-inclusive-development" target="_blank"> <img src="images/publications/the-vision-of-slum-free-indian-cities.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Sroll | Rahul Kadri</div>
                        <div class="artical_name">The vision of slum-free Indian cities needs to be viewed through the lens of inclusive development</div>
                        <div class="artical_date">september, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.constructionworld.in/Latest-Updates-On-Construction-Companies/indias-top-architects-and-indias-top-builders/24171" target="_blank"> <img src="images/publications/indias-top-architects.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">CWAB  |  </div>
                        <div class="artical_name">India’s Top Architects and India’s Top Builders</div>
                        <div class="artical_date">september, 2020 </div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://www.freepressjournal.in/mumbai/sobos-what-a-mess" target="_blank"> <img src="images/publications/the-free-press-journal.jpg" alt="" /></a> </div>
                        <div class="mag_name">The Free Press Journal | S. Adimulam  </div>
                        <div class="artical_name">Mumbai Rains: Residents link waterlogging to land reclamation for Coastal Road project </div>
                        <div class="artical_date">August, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/the-road-to-wellville.pdf" target="_blank"> <img src="images/publications/the-road-to-wellville.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">IFJ | Aadrita Chatterji </div>
                        <div class="artical_name">The Road to Wellville</div>
                        <div class="artical_date">september, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/inscape-a-place-to-heal.pdf" target="_blank"> <img src="images/publications/a-place-to-heal.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Inscape | Ar. Jayakrishnan Ranjit </div>
                        <div class="artical_name">A Place to Heal – “The overall design of the hospital is both welcoming and peaceful.”</div>
                        <div class="artical_date">August, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="https://wfmmedia.com/e-magazine/40955/" target="_blank"> <img src="images/publications/window-facade-magazine.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Window & Façade Magazine | </div>
                        <div class="artical_name">Post Pandemic Façade & Fenestration Designs </div>
                        <div class="artical_date">August, 2020 </div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/architects-and-interiors-india.pdf" target="_blank"> <img src="images/publications/landmark.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Architects and Interiors India | </div>
                        <div class="artical_name">IMK Architects Auric Hall is a landmark in India</div>
                        <div class="artical_date">August, 2020 </div>
                      </div>
             
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="auric-hall-by-imk-architects-gives-a-modern-spin-to-traditional-mughal-architecture.php" target="_blank"> <img src="images/publications/elle-decor-july20.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Elle Decor | Sakshi Rai</div>
                        <div class="artical_name">Auric Hall by IMK Architects gives a modern spin to Mughal Architecture</div>
                        <div class="artical_date">July, 2020</div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="design-for-tackling-pandemics.php" target="_blank"> <img src="images/publications/healthcare-radius-july20.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Healthcare Radius  | Rahul Kadri</div>
                        <div class="artical_name">Designs for tackling Pandemics ways to optimise building energy consumption</div>
                        <div class="artical_date">July, 2020</div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="the-indian-healthcare-system-needs-an-overhaul.php" target="_blank"> <img src="images/publications/et-healthworld-july20.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Healthworld.com  | Sakshi Rai</div>
                        <div class="artical_name">The Indian Healthcare System needs an Overhaul</div>
                        <div class="artical_date">July, 2020</div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="when-modernity-takes-cues-from-its-traditional-roots-auric-hall-by-imk-architects.php" target="_blank"> <img src="images/publications/commercialdesignindia.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Commercial Design |</div>
                        <div class="artical_name">When modernity takes cues from its traditional roots - AURIC Hall by IMK Architects
                        </div>
                        <div class="artical_date">July, 2020</div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="how-biophilic-and-interactive-design-interventions-could-help-make-hospitals-pandemic-proof.php" target="_blank"> <img src="images/publications/express-healthcare-july20.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The Indian Express   | Viveka Roychowdhury</div>
                        <div class="artical_name">  How biophilic and interactive design interventions could help make hospitals pandemic-proof</div>
                        <div class="artical_date">June, 2020</div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="a-post-pandemic-design-revolution.php" target="_blank"> <img src="images/publications/india-today-insight-july20.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">India Today   | Ridhi Kale</div>
                        <div class="artical_name"> A post-pandemic design revolution</div>
                        <div class="artical_date">April, 2020</div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="symbiosis-hospital-and-research-center-pune-by-imk-architects.php" target="_blank"> <img src="images/publications/commercialdesignindia2.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">Commercial Design </div>
                        <div class="artical_name"> Symbiosis Hospital And Research Center, Pune by IMK Architects</div>
                        <div class="artical_date">Jan  2020</div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="covid-19-cross-infection-can-be-tackled-through-hospital-design-changes-say-architects.php" target="_blank"> <img src="images/publications/indian-express-july20.jpg" alt="" /></a>
                        </div>
                        <div class="mag_name">The New Indian Express | Rahul Kadri</div>
                        <div class="artical_name">COVID-19: Cross-infection Can Be Tackled Through Hospital Design Changes</div>
                        <div class="artical_date">July, 2020</div>
                      </div>
                    </div>
                  </section>

                  <!--Page 7-->
                  <section>
                   
                    <div class="Publications_Row">
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/auric-hall-inauguration-2019.pdf" target="_blank"> <img src="images/publications/auric-hall-inauguration-2019.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Auric Hall - Inauguration  <span>2019</span></div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/auric-hall-bhumi-pujan-2016.pdf" target="_blank"> <img src="images/publications/auric-hall-bhumi-pujan-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Auric Hall Bhumi Pujan  <span>2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/mumbai-mirror-2019.pdf" target="_blank"> <img src="images/publications/mumbai-mirror-2019.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Mumbai Mirror   <span>2019</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/architects-interiors-hot.pdf" target="_blank"> <img src="images/publications/architects-interiors-hot.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Architects & Interiors Hot 100 <span>(2018, 2017, 2016, 2014)</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/construction-architecture-updatejan-feb17.pdf" target="_blank"> <img src="images/publications/construction-architecture-updatejan-feb17.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Construction & Architecture Update <span>Jan-Feb 2017</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/fensterbau-frontale-india-14th-tabloid-2016.pdf" target="_blank"> <img src="images/publications/fensterbau-frontale-india-14th-tabloid-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> Fensterbau Frontale India 14th Tabloid <span>2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/mondo-arc-india-2016.pdf" target="_blank"> <img src="images/publications/mondo-arc-india-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Mondo-arc India <span>2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/im-kadri-book2016.pdf" target="_blank"> <img src="images/publications/im-kadri-book2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> I.M.Kadri Book, published  <span>2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/a-plus-d-dec-2016.pdf" target="_blank"> <img src="images/publications/a-plus-d-dec-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> A plus D   <span>Dec 2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/ia-b-apr16.pdf" target="_blank"> <img src="images/publications/ia-b-apr16.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">IA & B  - Mr. I.M. Kadri <span>Apr 2016</span></div>
                      </div>
        
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/ia-b-rahul-kadri-apr16.pdf" target="_blank"> <img src="images/publications/ia-b-rahul-kadri-apr16.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">IA & B  - Mr. Rahul Kadri <span>Apr 2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/decorama-jun-2016.pdf" target="_blank"> <img src="images/publications/decorama-jun-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Decorama <span>Jun 2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/imk-book-launch-2016.pdf" target="_blank"> <img src="images/publications/imk-book-launch-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">IMK Book Launch   <span>2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/imk-book-newpapers-pre-launch-2016.pdf" target="_blank"> <img src="images/publications/imk-book-newpapers-pre-launch-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">IMK Book Newpapers Pre-Launch   <span>2016</span></div>
                      </div>
                      
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/domus-imk-mar-2016.pdf" target="_blank"> <img src="images/publications/domus-imk-mar-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Domus  IMK<span>Mar 2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/ace-update-feb-2016.pdf" target="_blank"> <img src="images/publications/ace-update-feb-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">ACE Update<span>Feb 2016</span></div>
                      </div>
                      
                    </div>
                  </section>

                  <!--Page 8-->
                  <section>
                    <div class="Publications_Row">
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/scroll-2016.pdf" target="_blank"> <img src="images/publications/scroll-2016.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> Scroll  <span> 2016</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/interiors-decor-dec-jan-2015.pdf" target="_blank"> <img src="images/publications/interiors-decor-dec-jan-2015.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> Interiors & Decor  <span> Dec - Jan 2015 </span></div>
                      </div>

                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/elle-decor-feb-2015.pdf" target="_blank"> <img src="images/publications/elle-decor-feb-2015.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> Elle Decor   <span> Feb 2015 </span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/decorama-sept-2015.pdf" target="_blank"> <img src="images/publications/decorama-sept-2015.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> Decorama   <span> Sept 2015 </span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/domus-jan-2015.pdf" target="_blank"> <img src="images/publications/domus-jan-2015.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Domus <span>Jan 2015</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/ssmb-mx-2015.pdf" target="_blank"> <img src="images/publications/ssmb-mx-2015.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">SSMB-MX  <span>2015</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/indian-architect-and-builder-mar-2015.pdf" target="_blank"> <img src="images/publications/indian-architect-and-builder-mar-2015.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Indian Architect and Builder   <span>Mar 2015</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/construction-and-architecture-update-jan-feb-2015.pdf" target="_blank"> <img src="images/publications/construction-and-architecture-update-jan-feb-2015.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Construction and Architecture Update    <span>Jan - Feb 2015</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/neptune-glitz-aug-2014.pdf" target="_blank"> <img src="images/publications/neptune-glitz-aug-2014.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> Neptune Glitz   <span>Aug 2014</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/construction-and-architecture-update-may-jun-2014.pdf" target="_blank"> <img src="images/publications/construction-and-architecture-update-may-jun-2014.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name"> Construction and Architecture Update    <span>May - Jun 2014</span></div>
                      </div>
 
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/neptune-glitz-jun-2014.pdf" target="_blank"> <img src="images/publications/neptune-glitz-jun-2014.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Neptune Glitz     <span>Jun 2014</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/steel-structures-and-metal-buildings-mar-2014.pdf" target="_blank"> <img src="images/publications/steel-structures-and-metal-buildings-mar-2014.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Steel Structures and Metal Buildings     <span>Mar 2014</span></div>
                      </div>
                   
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/architect-and-interiors-india-mar-2014.pdf" target="_blank"> <img src="images/publications/architect-and-interiors-india-mar-2014.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Architect and Interiors India     <span>Mar 2014</span></div>
                      </div>
                    
                      <div class="Publications_Box">
                        <div class="Publications_Thum">
                            <a href="images/publications/domus-structuring-beauty.pdf" target="_blank"> <img src="images/publications/domus-structuring-beauty.jpg" alt="" /></a>
                        </div>
                        <div class="Publications_Name">Domus – Structuring Beauty   </div>
                      </div>
                    </div>
                  </section>

              </div>


           
            <div class="clr"></div>
            <div id="pagingControls"></div>
          </div>
        </div>

        <div class="clr"></div>
      </div>

  </div>
</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      

<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script></body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>I M Kadri</title>

<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>
</head>

<body>

<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="active" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main_inner">
   <!--slider
    <div class="inner_banner">
       <img src="images/inner-banner.jpg">
       <div class="banner_text">
          <div class="Title"> Team</div>
      </div>
    </div>
-->
    
    <div class="Inner_Page">
      <div class="breadcrumb mrg_btm top_bdr">
          <div class="container">
            <ul>
                <li><a href="index.php"><i class="fa_bedcrum fa-home" aria-hidden="true"></i></a></li>
                <li><a href="#">media</a></li>
                <li>Idealog</li>
            </ul>
          </div>
      </div>
      
      <div class="Idealog_Section">
        <div class="container">
          <h1 class="Title">Idealog</h1>
          <div class="row">
            <div id="content">

              <section>
                <div class="Idealog_Row">
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="participatory-democracy-a-blueprint-for-inclusive-city-making.php">
                         <img src="images/idealog/participatory-democracy.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Participatory Democracy: A Blueprint for Inclusive City-Making</div>
                    <p>The past few years have seen some contentious urban development projects in our country. So what should be the ideal planning process for public projects?</p>
                    <div class="seo_word"><a href="urban-design-and-town-planning.php">Urban Planning   </a> <a href="#">Development </a> <a href="#">Cities </a></div>
                  </div>

                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="the-future-of-education-design-lies-in-creating-flexible-learning-environments.php">
                         <img src="images/idealog/education-design.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">The Future of Education Design Lies in Creating Flexible Learning Environments</div>
                    <p>There is an imminent need to re-think our model of educational design and conscientiously adopt one that aids in building a safer community to cultivate learning.</p>
                    <div class="seo_word"><a href="educational.php">Education </a> <a href="educational.php">School Design</a> </div>
                  </div>
     
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="creating-places-where-people-thrive-imk-architects-approach-to-urban-design-and-master-planning.php">
                         <img src="images/idealog/urban-design-master-planning.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Creating Places Where People Thrive: IMK Architects’ Approach to Urban Design and Master-Planning </div>
                    <p> Within large-scale master-planning and housing projects, the understanding of the intricate relationship between man and environment assumes critical relevance.</p>
                    <div class="seo_word"><a href="#">Town Planning  </a> <a href="urban-planning.php">Urban Design</a> </div>
                  </div>

                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="three-simple-solutions-to-all-our-transportation-and-congestion.php">
                         <img src="images/idealog/the-larger-question-remains.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Three Simple Solutions to All Our Transportation and Congestion  </div>
                    <p>The larger question remains – what led to the transportation problem being the way it is? The answer to these lies in 3 simple solutions.</p>
                    <div class="seo_word"><a href="educational.php">Education  </a> <a href="#">Campus Planning </a> </div>
                  </div>

                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="the-year-gone-by-design-director-anuprita-dixit-on-learning-from-the-pandemic.php">
                         <img src="images/idealog/renewed-zeal.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">The Year Gone By: Design Director Anuprita Dixit on Learning from the Pandemic</div>
                    <p>We look back at 2020 with positivity and seek to carry forward all our learnings in the future with renewed zeal and determination. </p>
                    <div class="seo_word"><a href="#">Work From Home  </a> <a href="#">Working Systems </a> </div>
                  </div>
           
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="formalising-the-informal-the-potential-of-self-development-of-slum-communities.php">
                         <img src="images/idealog/formalising-the-informal.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Formalising the Informal: The Potential of Self-Development of Slum Communities</div>
                    <p>The vision of a slum-free city needs to be viewed through the lens of inclusive development.</p>
                    <div class="seo_word"><a href="urban-planning.php">Urban Planning   </a> <a href="#">Slum Redevelopment</a></div>
                  </div>
   
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="coastal-road-projects-dont-just-damage-the-environment-they-are-also-out-dated.php">
                         <img src="images/idealog/coastal-road.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Coastal Road Projects Don't Just Damage the Environment – They Are Also Out-dated</div>
                    <p>While many cities in the West are moving towards being more walk-able, India is still building infrastructure for cars.</p>
                    <div class="seo_word"><a href="urban-planning.php">Urban Planning   </a> <a href="community-development.php">Development  </a> <a href="#">Cities  </a> </div>
                  </div>
     
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="what-is-maharashtras-self-redevelopment-scheme-for-housing-societies-and-why-it-needs-a-financial-lifeline.php">
                         <img src="images/idealog/housing-societies.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">What Is Maharashtra’s Self-Redevelopment Scheme for Housing Societies and Why It Needs a Financial Lifeline  </div>
                    <p>The democratic model of self-redevelopment needs to be safeguarded if we are to solve Mumbai’s housing crisis.</p>
                   <div class="seo_word"><a href="urban-planning.php">Urban Planning   </a>  <a href="#">Cities  </a> <a href="#">Housing  </a></div>
                  </div>

                </div>
                
               
              </section>

              <!--Page2--->
              <section>
                <div class="Idealog_Row">
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="a-good-university-campus-can-create-a-lasting-impact.php">
                         <img src="images/idealog/university-campus.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">A Good University Campus creates an immense impact on the quality of the college experience. </div>
                    <p>University Campuses must be designed using social and sustainable principles. to create a lasting impact on students.</p>
                    <div class="seo_word"><a href="educational.php">Education  </a> <a href="#">Campus Planning  </a> </div>
                  </div>
  
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="design-strategies-for-improved-next-generation-hospitals.php">
                         <img src="images/idealog/design-strategies.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Design Strategies for Improved Next Generation Hospitals</div>
                    <p>Next Generation Hospitals must employ modern design strategies to improve the standard of healthcare in India.</p>
                    <div class="seo_word"><a href="healthcare.php">Healthcare</a> <a href="#">Economics</a> <a href="healthcare.php">Hospitals</a> </div>
                  </div>
   
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="upgrading-the-indian-healthcare-infrastructure.php">
                         <img src="images/idealog/upgrading-the-indian.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Upgrading the Indian Healthcare<span> Infrastructure</span></div>
                    <p>Need for increase in Investment in India’s Healthcare system.</p>
                    <div class="seo_word"><a href="healthcare.php">Healthcare</a> <a href="#">Economics</a> <a href="healthcare.php">Hospitals</a> </div>
                  </div>
     
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="the-pandemic-calls-for-critical-changes-in-how-we-design-cities.php">
                         <img src="images/idealog/the-pandemic-calls.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">The Pandemic Calls for Critical Changes in How We Design Cities</div>
                    <p>The COVID-19 crisis has brought to the forefront the shortcomings of metropolises of India </p>
                    <div class="seo_word"><a href="urban-planning.php">Urban Planning </a> <a href="#">Cities</a> <a href="#">Housing</a> </div>
                  </div>
   
                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="is-mumbai-indias-sinking-city.php">
                         <img src="images/idealog/is-mumbai-indias-sinking-city.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Is Mumbai India’s Sinking City ?</div>
                    <p>Rahul Kadri in conversation with Rajdeep Sardesai on ‘Mumbai India’s Sinking City?’ India Today, August 06, 2020 </p>
                    <div class="seo_word"><a href="urban-planning.php">Urban Planning </a> <a href="#">Development </a> <a href="#">Cities</a>  </div>
                  </div>

                  <div class="Idealog_Box">
                    <div class="Idealog_Thum">
                        <a href="next-generation-hospitals-the-need-of-the-hour.php">
                         <img src="images/idealog/next-generation-hospitals.jpg" alt="" />
                       </a>
                    </div>
                    <div class="Idealog_Name">Next Generation Hospitals – The Need of the Hour!</div>
                    <p>Development of better-designed new generation hospitals can help improve the healthcare system in India.</p>
                    <div class="seo_word"><a href="healthcare.php">Healthcare</a> <a href="#">Economics</a> <a href="healthcare.php">Hospitals</a></div>
                  </div>
                </div>
              </section>

            </div>
            
            <div class="clr"></div>
            <div id="pagingControls"></div>
      
            
       

            

           
            
          </div>
        </div>

        <div class="clr"></div>
      </div>

  </div>
</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      

<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script>
</body>
</html>
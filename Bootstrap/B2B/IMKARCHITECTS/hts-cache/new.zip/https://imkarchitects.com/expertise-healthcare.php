<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>Healthcare architects in India</title>
<meta name="description" content="For new age healthcare design companies get in touch with us – one of the best Hospital Architecture Firms in Mumbai,India" />
<meta name="keywords" content="Healthcare Architects, Healthcare Architects In India, Healthcare Architects In Mumbai, Healthcare Design Companies, Hospital Architect, Hospital Architecture In India, Healthcare Architecture Firms In India, Hospital Architecture Firms, Hospital Architects In India" />

<link href="css/bootstrap.css" rel="stylesheet">
<link href='css/custom.css' rel='stylesheet' type='text/css'>
<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>
</head>

<body>

<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="active" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main_inner">
   <!--slider-->
    <div class="inner_banner">
       <img src="images/expertise-healthcare-banner.jpg">
       <div class="banner_text">
          <div class="Title"> Healthcare</div>
      </div>
    </div>

    
    <div class="Inner_Page">
      <div class="breadcrumb">
          <div class="container">
            <ul>
                <li><a href="index.php"><i class="fa_bedcrum fa-home" aria-hidden="true"></i></a></li>
                <li><a href="#">Expertise</a></li>
                <li>Healthcare</li>
            </ul>
          </div>
      </div>
      <div class="container pd_tb">
        <h1 class="Title pd_tp2">The New Generation Healthcare Design</h1>
        <div class="textp">IMK Architects has 50 years of experience designing<span> Hospitals and is constantly striving to build the best Next Generation Hospitals</span></div>

        <div class="healthcare_box">
            <div class="row">
                <div class="col-sm-4">
                    <div class="healthcare_service">
                      <div class="healthcare_name">
                        minimise <span>cross infection</span>
                      </div>
                      <p>By having effective <span>natural ventilation</span></p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="healthcare_service">
                      <div class="healthcare_name">
                        segregation <span>of zones</span>
                      </div>
                      <p>Thorough segration of <span>general semi-sterile &</span> sterile zones</p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="healthcare_service">
                      <div class="healthcare_name">
                        nett zero <span>energy systems</span>
                      </div>
                      <p>Nett Zero designs <span>leading to huge</span> <span>savings in operation</span> costs</p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="healthcare_service">
                      <div class="healthcare_name">
                        patient centric <span>designs</span>
                      </div>
                      <p>Designed for faster healing <span>with connection to nature</span> <span>and apt interconnectivity</span> of departments</p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="healthcare_thum">
                      <img src="images/healthcare-service-thum.jpg" alt="" />
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="healthcare_service">
                      <div class="healthcare_name">
                        servicibility <span>& engineering</span>
                      </div>
                      <p>Apt location of services <span>and maintenance areas.</span> <span>Engineered to be built in</span> 12 months</p>
                    </div>
                </div>
            </div>
        </div>  
      </div>

      <div class="healthcare_section_one">
        <div class="row">
            <div class="col-sm-4">
                <div class="thum">
                  <img src="images/healthcare-thum1.jpg" alt="" />
                </div>
            </div>
            <div class="col-sm-4">
                <div class="thum">
                  <img src="images/healthcare-thum2.jpg" alt="" />
                </div>
            </div>
            <div class="col-sm-4">
                <div class="thum">
                  <img src="images/healthcare-thum3.jpg" alt="" />
                </div>
            </div>
        </div>
        <div class="container">
        <div class="Title">I.M.K Architects</div>
        <p>We believe good designs benefits all partakers - patients, doctors, staff, and ofcourse Hospital
          Developers. To arrive at design solutions for our healthcare clients, we often derive innovative
          ideas from our expertise of other sectors like Hospitality, education or commercial. The benefit of
          working with a multidisciplinary design firm is the ability to gather and translate understandings
          from these projects into usable information for the healthcare sector.</p>
        </div>
      </div>

      

      <div class="healthcare_section_three">
          <div class="container">
            <div class="Title">our designs are</div>
          <div class="cat_section">
            <div class="row">
                  <!--concious-->
                  <div class="cat_home">
                    <div class="col-sm-6 animatedParent">
                        <div class="lt animated fadeInLeftShort delay-500 go">
                        <div class="thum">
                            <a href="#"><img src="images/concious-thum.jpg" alt=""></a>            
                        </div>
                    </div>
                    </div>
                    <div class="col-sm-6 animatedParent">
                      <div class="rt animated fadeInRightShort delay-500 go">             
                          <div class="arrow_box pdtlr">               
                             <h4> <span>Concious</span></h4>
                            <p>Our designs of Healthcare facility transcend to
                                help patients’ recuperate effectively, include
                                safety and promote productivity & innovation.
                                It is our focus to design carefully for all
                                stakeholders for its entire life cycle.</p>
                                           
                          </div>
                        </div>
                    </div>
                    <div class="clr"></div>
                  </div>

                  <!--process driven-->
                  <div class="cat_home">
                    <div class="col-sm-6 mbox animatedParent">
                        <div class="lt animated fadeInLeftShort delay-500">
                            <div class="thum">
                                <a href="#"><img src="images/process-driven-thum.jpg" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 animatedParent">
                        <div class="rt animated fadeInRightShort delay-500">                
                             <div class="arrow_box pdtr">
                             <h4> <span>Process Driven</span></h4>
                            <p>We have a unique process to efficiently evaluate the
                                best functional, Cost and Energy efficient strategies
                                for integrating in a health care facility.
                                We help formulate an optimum design brief with the
                                flexibility to make the facility future proof </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 dbox animatedParent">
                      <div class="lt animated fadeInRightShort delay-500 go">
                        <div class="thum">
                            <a href="#"><img src="images/process-driven-thum.jpg" alt=""></a>
                        </div>
                      </div>
                    </div>
                    
                 
                    
                    <div class="clr"></div>
                  </div>   

                  <!--complete-->
                  <div class="cat_home">
                    <div class="col-sm-6 animatedParent">
                        <div class="lt animated fadeInLeftShort delay-500 go">
                        <div class="thum">
                            <a href="#"><img src="images/complete-thum.jpg" alt=""></a>            
                        </div>
                    </div>
                    </div>
                    <div class="col-sm-6 animatedParent">
                      <div class="rt animated fadeInRightShort delay-500 go">             
                          <div class="arrow_box pdtlr">               
                             <h4> <span>Complete</span></h4>
                            <p class="pdlr">We are focused to devise a solution which
                                promote better health, than just
                                healthcare.</p>
                               <p class="pdlr"> Our designs always strive towards
                                reducing Life cycle cost of the facility.
                                A building which epitomizes healing in all
                                senses </p>
                                           
                          </div>
                        </div>
                    </div>
                    <div class="clr"></div>
                  </div>

            </div>
          </div>
        </div>

      </div>


      <div class="healthcare_section_two">
          <div class="container">
              <div class="Sub_Title">
                IMK architects offers the best Healthcare design solutions for your project 
              </div>
          </div>
      </div>


      <!--four point-->
      <div class="healthcare_section_four">
        <div class="four_point">
          <div class="container">
              <div class="four_point_inner">
                <div class="row">
                    <div class="col-sm-7">
                      <div class="point_box" style="background:#e3e9ed;">
                          <div class="num" style="color: #000;">8</div>
                          <div class="Title" style="color:#fd6100">design <span>considerations</span></div>
                          <p>For a Healthcare Building</p>
                      </div>
                      <div class="point_box" style="padding:56px 0px;">
                          <div class="num" style="color:#616262">3</div>
                          <div class="Title" style="color:#000">key features</div>
                          <p style="color:#fd6100">Of a NET ZERO Healthcare Building</p>
                      </div>
                    </div>
                    <div class="col-sm-5">
                      <div class="point_box" style="padding-bottom:38px;">
                          <div class="num" style="color:#fd6100">5</div>
                          <div class="Title" style="color:#fff">things</div>
                          <p>To avoid while Healthcare Planning and Design </p>
                      </div>
                      <div class="point_box" style="background:#f0f2f4;">
                          <div class="num" style="color:#616262">7</div>
                          <div class="Title" style="color:#fd6100">important <span>factors</span></div>
                          <p>To consider For selecting an Architect for Healthcare Buildings</p>
                      </div>
                    </div>
                </div>
              </div>
          </div>
        </div>
      </div>

 
      <!--enquire now-->
      <div class="enquire_now">
          <div class="container">
              <h3 class="Title">enquire now !</h3>
              <div class="row">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/expertise-health.php" method="post" id="register-interest-form" role="form">
                    <div class="controls">
                        <div class="row">
                                       
                            <div class="col-sm-4">
                                <div class="form-group">
                                     <input type="text" name="name" id="name" placeholder="Name" required class="form-control" data-error="Name is required.">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                          
                            <div class="col-sm-4">
                                <div class="form-group">
                              
                                    <input id="form_lastname" type="number" name="pnumber" class="form-control" placeholder="Phone Number" required
                                        data-error="Phone Number is required.">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                           
                            <div class="col-sm-4">
                                <div class="form-group">
                             
                                    <input id="form_email" type="email" name="email" class="form-control" placeholder="Email" required
                                        data-error="Valid email is required.">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                           
                             <div class="col-sm-12">
                               <div class="form-group">
                               
                                    <textarea id="form_message" name="address" class="form-control" placeholder="Address" rows="4" required
                                        data-error="Address is required."></textarea>
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>

                      
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <input type="submit" class="btn btn-success btn-send" value="Submit">
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="messages"></div>
                </form>
              </div>
          </div>  
      </div>

  </div>
 

    

</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      
<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>Team IMK </title>
<meta name="description" content="Experienced & proficient architectural team working passionately to achieve client goals" />
<link rel="shortcut icon" href="images/favicon.ico"type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" type="text/css" rel="stylesheet" />
<!---fonts-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700&display=swap" rel="stylesheet">
<!---menu-->
<link rel="stylesheet" href="css/menu-style.css" type="text/css" media="all" />
<!-- slider -->
<link href="owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.theme1.css" rel="stylesheet" type="text/css" />
<link href="owl-carousel/owl.transitions.css" rel="stylesheet" type="text/css" />
<!-- form -->
<link href="css/form.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!---colorbox-->
<link rel="stylesheet" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170630250-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170630250-1');
</script>
</head>

<body>
<!--Mr. B. K. Sinha-->
<div class="popup_box" id="modal_one">
    <div class="Box_Inner">
        <div class="d_name">Mr. I.M. Kadri</div>
        <div class="designation">Partner & Principal Architect B.E. (Civil) </div>
        <div class="details">
            <p> Mr. I.M. Kadri, Founder, Partner and Principal Architect of I.M.Kadri Architects successfully established his Architectural practice in Mumbai in 1960. Through a career spanning over five decades, Mr. I.M. Kadri has had an unrivalled commitment to professional aesthetics, competence and utility for his creations.</p>

            <p> As an Architect he has left his imprint on landmark buildings in several important cities of India, the Middle East, Hong Kong, Tajkistan and other places. These include hospitals (from 50 to 500 beds), five star hotels, educational institutions, college campuses, industrial townships and also a film city.</p>

            <p> One creation of Mr. Kadri earned him an entry into the Guiness Book of Records – the world’s highest stained glass mural, 135 feet tall, at the Ramada hotel, Dubai. </p>

            <p> Each design and construction of Mr. Kadri has a philosophy behind it – ultimately merging the building into the background and capturing the ethos and the ambience of the site. He places great emphasis on landscaping for all his buildings, giving each one a mark of distinction.</p>

            <p> Recognized as one of the most innovative Architects internationally, he has been bestowed with several personal and professional honors for his contribution to the field.</p>

            <p> His work brought him listings in ”Who’s Who in the World” and “Men of Achievements” (of International Bio-graphical Centre, Cambridge, U.K). He was also awarded a citation in 1993 as an Outstanding Architectural Engineer by the Institution of Engineers (India). He won the Best Design Award at the International Competition for the Kowloon Mosque in Hong Kong.</p>

            <p> Mr. Kadri was one of 17 architects world-wide invited to the Convention of World Architects held in Isfahan in 1970. He has also been a member of the Joint Committee on tall Building, Lehigh University, U S A (under UNESCO).</p>

            <p> Apart from pursuing architectural excellence, equally strong, has been Mr.Kadri’s keen involvement in social welfare activities, housing the under-privileged sections of society and administrative experience.</p>

            <p> He has been nominated by the Prime Minister of India as advisor in the Committee for the Exhibition on Islamic Heritage for the Centenary Celebrations of Hijri Era. He is honorary architect to the Government of Maharashtra, member of the High Power Steering Group for Slums and Dilapidated Houses in Mumbai, the Advisory Committee on Management and Development of Borivali National Park, General Secretary of Nehru Centre, Executive Committee member of Bombay Metropolitan Region Development Authority, and a former Chairman of the Maharashtra Tourism Development Corporation Ltd.</p>

            <p> In recognition of his extensive social work, the Government of Maharashtra appointed him Sheriff of Bombay in 1994.</p>

        </div>
        <span class="close_btn modal_close"><i class="fa_close fa-times-circle" aria-hidden="true"></i></span> 
        <div class="clr"></div>
    </div>
</div>

<!--Mr. Amitesh Sinha-->
<div class="popup_box" id="modal_two">
    <div class="Box_Inner">
        <div class="d_name">Mr. Rahul Kadri</div>
        <div class="designation">Partner & Principal Architect M.U.P. </div>
        <div class="details">
            <p> Mr. Rahul Kadri is Principal Architect & Partner at I.M.Kadri Architects.
            Mr. Rahul Kadri spent his formative years amidst lush landscapes exploring the forests of the Kumaon Himalayas while studying at Sherwood College, Nainital. This early relationship with nature infused within him with a deep passion to create buildings & spaces, which are in harmony with its natural context.</p>
            <p> He completed his diploma in architecture from the Academy Of Architecture, Mumbai and went on pursue his master’s degree in Urban Planning from University of Michigan, Ann Arbor (1988). </p>
            <p> He assumed directorship of Kadri Consultants Pvt. Ltd in 1995 and since then has designed & executed several architecture & town planning projects under his leadership. He has designed townships for Tata’s, Jindal’s & Reliance, Hotels & Resorts for Taj & Club Mahindra, College Campuses for Symbiosis & The Supreme Court Of India and more. Over the years he has honed his skill & passion to create places where people and nature thrive.</p>
            <p> Apart from his engagement with architecture Mr. Rahul Kadri has been actively involved in proposals for the effective development of open spaces in Mumbai.</p>
            <p> Mr. Kadri is a Trustee of Save The Children India – an organization committed to the cause of the education of the least privileged children in India</p>
        </div>
        <span class="close_btn modal_close"><i class="fa_close fa-times-circle" aria-hidden="true"></i></span> 
        <div class="clr"></div>
    </div>
</div>


<div class="loader">
  <div class="icon"><img src="images/generatorphp-thumb.gif" width="64" height="64"><br/></div>
</div>
<header>
    <div class="container clearfix">
        <div class="logo">
            <a href="http://imkarchitects.com/"><img src="images/logo.jpg" alt="" /></a>
        </div>
        <nav>
            <div id="nav">
              <input id="main-menu-state" type="checkbox" />
              <label class="main-menu-btn" for="main-menu-state"> <span class="main-menu-btn-icon"></span> <span class="main-menu-btn-text">Toggle main menu visibility</span> <span class="main-menu-btn-title" aria-hidden="true"> <span aria-hidden="true" data-icon="h"></span></span> </label>
                <ul id="main-menu" class="sm sm-blue collapsed">
                    <li><a class="active" href="#">firm</a>
                        <ul class="sub-menu">
                            <li><a href="profile.php"> Profile </a></li>
                            <li><a href="philosophy.php"> Philosophy </a></li>
                            <li><a href="process.php"> Process </a></li>
                            <li><a href="services.php"> Services </a></li>
                            <li><a href="history.php"> History </a></li>
                            <li><a href="clients.php"> Key Clients </a></li>
                            <li><a href="team.php"> Team </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">expertise</a>
                        <ul class="sub-menu">
                            <li><a href="self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="expertise-healthcare.php"> Healthcare </a></li>
                            <li><a href="expertise-educational.php"> Educational </a></li>
                            <li><a href="expertise-hospitality.php"> Hospitality </a></li>
                        </ul>
                    </li>   
                    <li><a class="" href="projects.php">projects</a>
                        <ul class="sub-menu">
                            <li><a href="hospitality.php"> Hospitality</a></li>
                            <li><a href="healthcare.php"> Healthcare </a></li>
                            <li><a href="commercial.php"> Commercial </a></li>
                            <li><a href="residential.php"> Residential  </a></li>
                            <li><a href="urban-planning.php"> Urban Planning </a></li>
                            <li><a href="educational.php"> Educational </a></li>
                            <li><a href="residential-self-redevelopment.php"> Self Redevelopment </a></li>
                            <li><a href="culture-and-leisure.php"> Culture and leisure </a></li>
                            <li><a href="community-development.php"> Community Development </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="#">media</a>
                        <ul class="sub-menu">
                            <li><a href="awards.php"> Awards</a></li>
                            <li><a href="publications.php"> Publications </a></li>
                            <li><a href="idealog.php"> Idealog </a></li>
                            <li><a href="events.php"> Events </a></li>
                            <li><a href="videos.php"> Videos </a></li>
                        </ul>
                    </li>
                    <li><a class="" href="contact.php">Contact</a></li>
                    <li><a class="" href="social-responsibility.php">social responsibility</a></li>
                </ul>
            </div>
        </nav>
        <div class="social_media">
            <a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media fa-instagram"></i></a>
            <a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media fa-linkedin-square"></i></a>
            <a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media fa-facebook-square"></i></a>
            <a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media fa-youtube-square"></i></a>
        </div>
        <div class="clr"></div>
    </div>
</header>
<div id="main_inner">
   <!--slider
    <div class="inner_banner">
       <img src="images/inner-banner.jpg">
       <div class="banner_text">
          <div class="Title"> Team</div>
      </div>
    </div>
-->
    
    <div class="Inner_Page">
      <div class="breadcrumb mrg_btm top_bdr">
          <div class="container">
            <ul>
                <li><a href="index.php"><i class="fa_bedcrum fa-home" aria-hidden="true"></i></a></li>
                <li><a href="#">Firm</a></li>
                <li>Team</li>
            </ul>
          </div>
      </div>
      
      <div class="Team_Section">
        <div class="container">
        <h1 class="Title">Team</h1>
      </div>
        <div class="team_row wow fadeInUp" style="visibility: visible; animation-name:fadeInUp;">
          <div class="container">
            <div class="Title">Partner</div>
            <div class="row">
              <div class="col-sm-2">
                <a id="popup1">
                <div class="team_member" style="cursor: pointer;">
                  <div class="member_photo"><img src="images/team/kadri.jpg" alt="" class="grayscale" /></div>
                  <div class="member_name">Mr. I.M. Kadri</div>
                  <div class="member_designation">Partner & Principal Architect</div>
                  <div class="member_qualification">B.E. (Civil)</div>
                </div>
                </a>
              </div>

              <div class="col-sm-2">
                <a id="popup2">
                <div class="team_member" style="cursor: pointer;">
                  <div class="member_photo"><img src="images/team/rahul-kadri.jpg" alt="" class="grayscale" /></div>
                  <div class="member_name">Mr. Rahul Kadri</div>
                  <div class="member_designation">Partner & Principal Architect</div>
                  <div class="member_qualification">M.U.P.</div>
                </div>
                </a>
              </div>

            </div>
          </div>
        </div>


 

        <div class="team_row wow fadeInUp" style="visibility: visible; animation-name:fadeInUp;">
          <div class="container">
            <div class="Title">Architects</div>
            <div class="row">
              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/anuprita-dixit.jpg" alt="Anuprita Dixit" /></div>
                  <div class="member_name">Anuprita Dixit</div>
                  <div class="member_designation">Design Director</div>
                  <div class="member_qualification">M. Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/nithin-hosabettu.jpg" alt="Nithin Hosabettu" /></div>
                  <div class="member_name">Nithin Hosabettu</div>
                  <div class="member_designation">Design Director</div>
                  <div class="member_qualification">B. Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/preeti-valanju.jpg" alt="Preeti Valanju" /></div>
                  <div class="member_name">Preeti Valanju</div>
                  <div class="member_designation">B.D. Manager</div>
                  <div class="member_qualification">B. Arch</div>
                </div>
              </div>

               <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/shraddha.jpg" alt="Shraddha" /></div>
                  <div class="member_name">Shraddha Kakade</div>
                  <div class="member_designation">Design Manager</div>
                  <div class="member_qualification">B. Arch</div>
                </div>
              </div>
              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/bhumika-ganjawala.jpg" alt="Bhumika Ganjawala" /></div>
                  <div class="member_name">Bhumika Ganjawala</div>
                  <div class="member_designation">Design Manager</div>
                  <div class="member_qualification">B. Arch</div>
                </div>
              </div>
              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/akbar-bashu.jpg" alt="Akbar Bashu" /></div>
                  <div class="member_name">Akbar Bashu</div>
                  <div class="member_designation">Design Manager</div>
                  <div class="member_qualification">B. Arch</div>
                </div>
              </div>
              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/m-b-gupte.jpg" alt="Mr. M.B. Gupte" /></div>
                  <div class="member_name">M.B. Gupte</div>
                  <div class="member_designation"> Architect</div>
                  <div class="member_qualification">G.D. Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/suvidha-hosabettu.jpg" alt="Suvidha Hosabettu" /></div>
                  <div class="member_name">Suvidha Hosabettu</div>
                  <div class="member_designation">Lead Architect</div>
                  <div class="member_qualification">B. Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/gayatri-railkar.jpg" alt="Gayatri Railkar" /></div>
                  <div class="member_name">Gayatri Railkar</div>
                  <div class="member_designation">Lead Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/priyamvada-patil.jpg" alt="Priyamvada Patil" /></div>
                  <div class="member_name">Priyamvada Patil</div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/shantaram-chalke.jpg" alt="Shantaram Chalke" /></div>
                  <div class="member_name">Shantaram Chalke</div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">Dip. Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/sahil-b-deshpande.jpg" alt="Sahil B. Deshpande" /></div>
                  <div class="member_name"> Sahil B. Deshpande</div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">M.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/heena-shaikh.jpg" alt="Heena Shaikh" /></div>
                  <div class="member_name"> Heena Shaikh</div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/viraj-naralkar.jpg" alt="Viraj Naralkar" /></div>
                  <div class="member_name">Viraj Naralkar </div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/aakash-shrivastav.jpg" alt="Aakash Kumar" /></div>
                  <div class="member_name">Aakash Kumar</div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/dhananjay-purohit.jpg" alt="Dhananjay Purohit" /></div>
                  <div class="member_name">Dhananjay Purohit </div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/ganesh-karigar.jpg" alt="Ganesh Karigar" /></div>
                  <div class="member_name">Ganesh Karigar  </div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/kruti-jangla.jpg" alt="Kruti Jangla" /></div>
                  <div class="member_name">Kruti Jangla </div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/deepika-ajmera.jpg" alt="Mrs. Deepika Ajmera" /></div>
                  <div class="member_name">Deepika Ajmera </div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/pooja-satam.jpg" alt="Pooja Satam" /></div>
                  <div class="member_name">Pooja Satam </div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">M.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/priya-tare.jpg" alt="Priya Tare" /></div>
                  <div class="member_name">Priya Tare</div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/roshni-chand.jpg" alt="Roshni Chand" /></div>
                  <div class="member_name">Roshni Chand </div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/sneha-chonkar.jpg" alt="Sneha Chonkar" /></div>
                  <div class="member_name">Sneha Chonkar</div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">B.Arch</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/tejashree-rajeshirke.jpg" alt="Tejashree Rajeshirke" /></div>
                  <div class="member_name">Tejashree Rajeshirke </div>
                  <div class="member_designation">Architect</div>
                  <div class="member_qualification">M.Urp</div>
                </div>
              </div>

                <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/prasad-shikre.jpg" alt="Mr. Prasad Shikre" /></div>
                  <div class="member_name">Prasad Shikre</div>
                  <div class="member_designation">Draughtsman</div>
                  <div class="member_qualification">D.M.E</div>
                </div>
              </div>


            </div>
          </div>
        </div>

         <div class="team_row wow fadeInUp" style="visibility: visible; animation-name:fadeInUp;">
          <div class="container">
            <div class="Title">Graphic Designer</div>
            <div class="row">
                <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/pramod-shelar.jpg" alt="Mr. Pramod Shelar" /></div>
                  <div class="member_name">Pramod Shelar </div>
                  <div class="member_designation">Graphic Designer</div>
                  <div class="member_qualification">B.F.A.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
  

        <div class="team_row wow fadeInUp" style="visibility: visible; animation-name:fadeInUp;">
          <div class="container">
            <div class="Title">Engineers</div>
            <div class="row">
              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/barindra-unde.jpg" alt="Barindra Unde" /></div>
                  <div class="member_name">Barindra Unde</div>
                  <div class="member_designation">General Manager - Contracts and Commercial </div>
                  <div class="member_qualification">DCE, BE Civil & ME C</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/harish.jpg" alt="Harish" /></div>
                  <div class="member_name">Harish Vyas</div>
                  <div class="member_designation">Sr. Project Co-ordinator</div>
                  <div class="member_qualification">B.E. (Civil)</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/hosing.jpg" alt="Hosing" /></div>
                  <div class="member_name">S.D. Hosing</div>
                  <div class="member_designation">Sr. Project Co-ordinator</div>
                  <div class="member_qualification">D.C.E.</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/shridhar-salgude.jpg" alt="Shridhar Salgude" /></div>
                  <div class="member_name">Shridhar Salgude</div>
                  <div class="member_designation">Project Engineer / Architect</div>
                  <div class="member_qualification">Dip. In Civil Engg. & B.Arch</div>
                </div>
              </div>

               <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/madiha-qureshi.jpg" alt=" Madiha Qureshi" /></div>
                  <div class="member_name"> Madiha Qureshi</div>
                  <div class="member_designation">Project Co-ordinator</div>
                  <div class="member_qualification">B.E.Civil</div>
                </div>
              </div>

            </div>
          </div>
        </div>
        
        <div class="team_row wow fadeInUp" style="visibility: visible; animation-name:fadeInUp;">
          <div class="container">
            <div class="Title">Administration</div>
            <div class="row">
              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/dinesh-poduval.jpg" alt="Dinesh Poduval" /></div>
                  <div class="member_name">Dinesh Poduval</div>
                  <div class="member_designation">Manager - Admin.</div>
                  <div class="member_qualification">B.Com</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/priyanka-pawar.jpg" alt="Priyanka Pawar" /></div>
                  <div class="member_name">Priyanka Pawar</div>
                  <div class="member_designation">Manager - Accounts</div>
                  <div class="member_qualification">B.Com</div>
                </div>
              </div>

               <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/sandeep-chavan.jpg" alt="Sandeep Chavan" /></div>
                  <div class="member_name">Sandeep Chavan</div>
                  <div class="member_designation">Executive - Admin.</div>
                  <div class="member_qualification">B.A.</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/ishtiyaque-sayed.jpg" alt="Ishtiyaque Sayed" /></div>
                  <div class="member_name">Ishtiyaque Sayed </div>
                  <div class="member_designation">Executive - Admin.</div>
                  <div class="member_qualification">Ishtiyaque Sayed </div>
                </div>
              </div>

            </div>
          </div>
        </div>

      

        <div class="team_row wow fadeInUp bdr" style="visibility: visible; animation-name:fadeInUp;">
          <div class="container">
            <div class="Title">Support Staff</div>
            <div class="row">
              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/santosh-chougule.jpg" alt="Santosh Chougule" /></div>
                  <div class="member_name">Santosh Chougule</div>
                  <div class="member_designation">Support Staff</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/wifred-pathinathan.jpg" alt="Wifred Pathinathan" /></div>
                  <div class="member_name">Wifred Pathinathan</div>
                  <div class="member_designation">Support Staff</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/dayanand-palav.jpg" alt="Dayanand Palav" /></div>
                  <div class="member_name">Dayanand Palav</div>
                  <div class="member_designation">Support Staff</div>
                </div>
              </div>

              <div class="col-sm-2">
                <div class="team_member">
                  <div class="member_photo"><img src="images/team/rajesh-nikalaje.jpg" alt="Rajesh Nikalaje" /></div>
                  <div class="member_name">Rajesh Nikalaje</div>
                  <div class="member_designation">Support Staff</div>
                </div>
              </div>

            </div>
          </div>
        </div>



        <div class="clr"></div>
      </div>

  </div>
</div>
    
<div class="footer">
    
<div>
  <div class="container">
      <div class="row">
     
          <div class="col-sm-4">
             <div class="ft_title">Mumbai Address</div>
             <ul class="cont">
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 4A, Shivsagar Estate, Dr. Annie Besant,  <br />Road Worli, Mumbai 400 018, India</li>
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 22-4050 6666/ 2497 3630</li>
                <li><span><i class="fa_cont2 fb fa-mobile-phone"></i></span> +91 9821488411 / +91 98338 03449</li>
                <li><span><i class="fa_cont fb fa-fax"></i></span> +91 22-2495 0520</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-5">
             <div class="ft_title">Bengaluru Address</div>
             <ul class="cont">
                <!--<li><span><i class="fa_cont fb fa-map-marker"></i></span> No-95, New No. 3,1st Floor, 8th Road, Near Jayamahal Water<br />Tank 2nd Cross, Nandidurga Road,  Bengaluru - 560046</li>-->
                 
                <li><span><i class="fa_cont fb fa-map-marker"></i></span> 196/A, Ground Floor, 4th Cross Rd, KHB Colony, <br /> 5th Block, Koramangala, Bengaluru, Karnataka 560095</li> 
                 
                <li><span><i class="fa_cont fb fa-phone"></i></span> +91 80 23432952</li>
                <li><span><i class="fa_cont fb fa-envelope"></i></span> <a href="mailto:info@imkarchitects.com"> info@imkarchitects.com</a>, <a href="mailto:media@imkarchitects.com"> media@imkarchitects.com</a></li>
              </ul>
          </div>
          <div class="col-sm-3">
             <div class="ft_title">Subscribe for Newsletter</div>
              <div class="subscrib">
                  <form name="register-interest-form" action="http://projects.spentadigital.com/imk/subscribe-form.php" method="post" id="register-interest-form" role="form">
                    <input placeholder="Your email address" type="email" name="email" class="subscribinput" required="" />
                    <button class="subscribbut" type="submit"></button>
                  </form>
                </div>
                 <div class="ft_title2">We are active on</div>
                 <ul class="social_media">
                 <li><a href="https://www.instagram.com/imkarchitects_india/" target="_blank"><i class="fa_media_btm fa-instagram"></i></a></li>
            <li><a href="https://www.linkedin.com/company/imk-architects/" target="_blank"><i class="fa_media_btm fa-linkedin-square"></i></a></li>
            <li><a href="https://www.facebook.com/Kadri-Consultants-Pvt-Ltd-267275110078622/" target="_blank"><i class="fa_media_btm fa-facebook-square"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCXk3hkekCP4yscM-lyZNdtA?view_as=subscriber" target="_blank"><i class="fa_media_btm fa-youtube-square"></i></a></li>
              </ul>
          </div>
      </div>
  </div>
</div>
<div class="footer_btm">&copy; 2020 IM Kadri Architects. All Rights Reserved. Site by <a href="http://www.spentadigital.com/" target="_blank"> Spenta Digital</a>
</div>
<div class="scrollToTop"><a href="#"><img src="images/top.png" alt="" /></a> </div>

</div>
      

<!-- header -->
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<!-- header -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>
<!--Team Page popup -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".modal_close").click(function(){
            $(".popup_box").fadeOut();
        });
        $("#popup1").click(function(){
            $("#modal_one").fadeIn();
        });
        $("#popup2").click(function(){
            $("#modal_two").fadeIn();
        });
    });
</script>
<!--pagination
<script src="js/jquery.min.js"></script>-->
<script src="js/imtech_pager.js" type="text/javascript"></script>
<script type="text/javascript">
var pager = new Imtech.Pager();
$(document).ready(function() {
    pager.paragraphsPerPage = 1; // set amount elements per page
    pager.pagingContainer = $('#content'); // set of main container
    pager.paragraphs = $('section', pager.pagingContainer); // set of required containers
    pager.showPage(1);
});
</script>

<!--Header-->
<script src="js/classie.js" type="text/javascript"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<!---ColorBox
<script src="jquery.min.js"></script>-->
<script src="js/jquery.colorbox.js" type="text/javascript"></script>
<script type="text/javascript" src="//wurfl.io/wurfl.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".youtube").colorbox({iframe:true, innerWidth:"80%", innerHeight:450});
        if(WURFL.is_mobile){
            $(".iframe").colorbox({iframe:true, width:"90%", height:"80%"});
        }else{
            $(".iframe").colorbox({iframe:true, width:"60%", height:"80%"});
        }     
    });
</script>
<!-- light box-->
<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="venobox/venobox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    /* default settings */
    $('.venobox').venobox(); 
    /* custom settings */
    $('.venobox_custom').venobox({
        framewidth: '400px',        // default: ''
        frameheight: '300px',       // default: ''
        border: '10px',             // default: '0'
        bgcolor: '#5dff5e',         // default: '#fff'
        titleattr: 'data-title',    // default: 'title'
        numeratio: true,            // default: false
        infinigall: true            // default: false
    });

    /* auto-open #firstlink on page load */
    $("#firstlink").venobox().trigger('click');
});
</script>
<!--menu-->
<script src="js/common.js" type="text/javascript"></script>
<!--slider-->
<script type="text/javascript">
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
     $(document).ready(function() {
      $("#owl-demo2").owlCarousel({
        autoPlay : 4000,
        stopOnHover : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade",
      });
    });
</script>

<!---thub-->
<link rel="stylesheet" href="css/thum_slider.css" type="text/css" media="screen">
<!--<script type="text/javascript" src="js/jquery-latest.min.js"></script> --> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>  
<script type="text/javascript" src="js/jquery.caroufredsel.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    //  carouFredSel
    $('#slider3 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev3',
        next: '.next3',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider3 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //


$(document).ready(function() {
    //  carouFredSel
    $('#slider4 .carousel.main ul').carouFredSel({
        auto: true,
        responsive: true,
        prev: '.prev4',
        next: '.next4',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '287',
            height: 'variable', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 4
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
        
    });
    $(window).bind("resize",updateSizes_vat).bind("load",updateSizes_vat);
    function updateSizes_vat(){     
        $('#slider4 .carousel.main ul').trigger("updateSizes");
    }
    updateSizes_vat();

}); //
$(window).load(function() {
    //

}); //
</script> 
 

<!---number scrol-->
<script src="js/numscroller-1.0.js" type="text/javascript"></script>
<!---animation-->
<script src="js/wow.min.js" type="text/javascript"></script>   
<!--Page Loader-->
<script type="text/javascript">
$(window).load(function() {
  $(".loader").fadeOut("slow");
})
setTimeout(show, 50);
</script>

<!--scroll top-->
<script src="js/scroll.js" type="text/javascript"></script>
</body>
</html>